export interface TimeState {
  day: number;
  turn: number;
}

export interface LocationState {
  systemId: string;
  docked: boolean;
}

export interface PlayerState {
  credits: number;
  roles: string[];
  wanted: number;
  hasChosenStarter: boolean;
}

export interface ShipState {
  templateId: string;
  name: string;
  hp: number;
  maxHp: number;
  shields: number;
  maxShields: number;
  fuel: number;
  maxFuel: number;
  cargoCapacity: number;
  cargo: Record<string, number>;
  modules: string[];
  weapons: (string | null)[];
  weaponPower: number;
  evasion: number;
  components: string[];
  hardpoints: {
    size: "small" | "medium" | "large";
    type: "energy" | "projectile" | "hybrid";
  }[];
}

export interface CombatState {
  enemyId: string;
  enemyName: string;
  enemyHp: number;
  enemyMaxHp: number;
  enemyShields: number;
  enemyMaxShields: number;
  enemyWeapons: string[];
  enemyCooldowns: number[];
  playerCooldowns: number[];
  playerBracing: boolean;
  canEscape: boolean;
  round: number;
  log: string[];
}

export interface ReputationTrack {
  [factionId: string]: number;
}

export interface ContractState {
  id: string;
  name: string;
  description?: string;
  type: string;
  status: "active" | "completed" | "failed";
  sourceFaction?: string;
  targetSystemId?: string;
  reward?: { credits?: number; rep?: Record<string, number> };
  requirements?: Record<string, unknown>;
  progress?: Record<string, unknown>;
  acceptedTurn?: number;
}

export interface TradeLogEntry {
  action: "buy" | "sell";
  commodityId: string;
  quantity: number;
  price: number;
  systemId: string;
  turn: number;
}

export interface GameState {
  version: number;
  time: TimeState;
  location: LocationState;
  player: PlayerState;
  ship: ShipState;
  reputation: ReputationTrack;
  contracts: ContractState[];
  combat: CombatState | null;
  notifications: string[];
  transactions: TradeLogEntry[];
  inventory: {
    weapons: string[];
  };
}

export let gameState: GameState;

export function newGameState(): GameState {
  return {
    version: 1,
    time: { day: 1, turn: 0 },
    location: { systemId: "helion_prime", docked: true },
    player: {
      credits: 1000,
      roles: ["trader"],
      wanted: 0,
      hasChosenStarter: false
    },
    ship: {
      templateId: "none",
      name: "Undefined Hull",
      hp: 0,
      maxHp: 0,
      shields: 0,
      maxShields: 0,
      fuel: 0,
      maxFuel: 0,
      cargoCapacity: 0,
      cargo: {},
      modules: [],
      weapons: [],
      weaponPower: 12,
      evasion: 5,
      components: [],
      hardpoints: []
    },
    reputation: {},
    contracts: [],
    combat: null,
    notifications: [],
    transactions: [],
    inventory: {
      weapons: ["laser_mk1"]
    }
  };
}

export function setGameState(state: GameState) {
  gameState = state;
}
