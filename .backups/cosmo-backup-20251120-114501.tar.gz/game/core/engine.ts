import { GameState, newGameState, setGameState, gameState } from "./state";
import { navigation } from "./navigation";
import { render } from "./renderer";
import type {
  SystemDef,
  ShipDef,
  ComponentDef,
  WeaponDef,
  CommodityDef,
  EnemyDef,
  GameContent
} from "./contentTypes";

/**
 * System definition (map node), matches systems.json.
 */
export type {
  SystemDef,
  ShipDef,
  ComponentDef,
  WeaponDef,
  CommodityDef,
  GameContent
} from "./contentTypes";

export let content: GameContent | null = null;

declare global {
  interface Window {
    nav: (screen: string, params?: Record<string, unknown>) => void;
  }
}

/**
 * Load all JSON content from /content.
 */
async function loadContent(): Promise<GameContent> {
  const [systemsResp, shipsResp, componentsResp, commoditiesResp, weaponsResp, enemiesResp] =
    await Promise.all([
      fetch("/content/systems.json"),
      fetch("/content/ships.json"),
      fetch("/content/components.json"),
      fetch("/content/commodities.json"),
      fetch("/content/weapons.json"),
      fetch("/content/enemies.json")
    ]);

  if (!systemsResp.ok) {
    throw new Error(`Failed to load systems.json: ${systemsResp.status}`);
  }
  if (!shipsResp.ok) {
    throw new Error(`Failed to load ships.json: ${shipsResp.status}`);
  }
  if (!componentsResp.ok) {
    throw new Error(`Failed to load components.json: ${componentsResp.status}`);
  }
  if (!weaponsResp.ok) {
    throw new Error(`Failed to load weapons.json: ${weaponsResp.status}`);
  }
  if (!commoditiesResp.ok) {
    throw new Error(`Failed to load commodities.json: ${commoditiesResp.status}`);
  }

  if (!enemiesResp.ok) {
    throw new Error(`Failed to load enemies.json: ${enemiesResp.status}`);
  }

  const systems: SystemDef[] = await systemsResp.json();
  const ships: ShipDef[] = await shipsResp.json();
  const components: ComponentDef[] = await componentsResp.json();
  const commodities: CommodityDef[] = await commoditiesResp.json();
  const weapons: WeaponDef[] = await weaponsResp.json();
  const enemies: EnemyDef[] = await enemiesResp.json();

  return { systems, ships, components, commodities, weapons, enemies };
}

/**
 * Initialize the runtime:
 * - load content
 * - create or load GameState
 * - patch navigation.go to auto-render
 * - render initial screen (starter select or main)
 */
export async function initGame() {
  // Load content
  content = await loadContent();

  // New game state (later you can check for saves)
  const initialState: GameState = newGameState();
  setGameState(initialState);

  // Patch navigation.go so every transition re-renders
  const originalGo = navigation.go.bind(navigation);
  navigation.go = (screen, params) => {
    originalGo(screen, params);
    render();
  };

  window.nav = (screen: string, params: Record<string, unknown> = {}) => {
    navigation.go(screen as any, params);
  };

  // Decide initial screen
  navigation.current = gameState.player.hasChosenStarter ? "main" : "ship_select";

  // Initial render
  render();
}

export function getSystemById(id: string): SystemDef | null {
  if (!content) return null;
  return content.systems.find((system) => system.id === id) ?? null;
}

export function getShipById(id: string): ShipDef | null {
  if (!content) return null;
  return content.ships.find((ship) => ship.id === id) ?? null;
}

export function getComponentById(id: string): ComponentDef | null {
  if (!content) return null;
  return content.components.find((c) => c.id === id) ?? null;
}

export { gameState };
