import { getCurrentSystem, getNeighbors, getRouteProfile } from "../systems/travelSystem";

declare const nav: (screen: string) => void;

export function TravelScreen(): string {
  const current = getCurrentSystem();
  const neighbors = getNeighbors();

  if (!current) {
    return `
      <div class="screen travel">
        <h1>Travel</h1>
        <p>Current system data unavailable.</p>
        <ul class="actions">
          <li onclick="nav('main')">Back to Main</li>
        </ul>
      </div>
    `;
  }

  const neighborList =
    neighbors.length === 0
      ? `<p>No nearby systems detected.</p>`
      : `<ul class="actions">
          ${neighbors
            .map((s) => {
              const profile = getRouteProfile(s.id);
              const securityLabel = formatSecurity(s.security);
              const tagNotes = formatTagNotes(s);
              const riskText = profile ? formatRisk(profile.hazardChance) : "Unknown";
              const fuelCost = profile ? `${profile.fuelCost} fuel` : "Fuel: ?";
              const travelTime = profile ? `${profile.travelTime} turn${profile.travelTime === 1 ? "" : "s"}` : "Time: ?";

              return `
                <li onclick="travelToSystem('${s.id}')">
                  <div>
                    <strong>${s.name}</strong>
                    <span class="muted">(${securityLabel}${tagNotes.length ? `, ${tagNotes.join(", ")}` : ""})</span>
                  </div>
                  <div class="muted">
                    ${fuelCost}, ${travelTime}, Risk: ${riskText}
                  </div>
                </li>
              `;
            })
            .join("")}
        </ul>`;

  return `
    <div class="screen travel">
      <h1>Travel</h1>
      <p>You are currently in <strong>${current.name}</strong>.</p>
      <p class="muted">${current.description}</p>

      <h2>Nearby Systems</h2>
      ${neighborList}

      <ul class="actions">
        <li onclick="nav('main')">Back to Main</li>
      </ul>
    </div>
  `;
}

function formatSecurity(security: string): string {
  switch (security) {
    case "high":
      return "High sec";
    case "medium":
      return "Mid sec";
    case "low":
      return "Low sec";
    default:
      return `${security || "Unknown"} sec`;
  }
}

function formatTagNotes(system: { tags: string[]; faction: string }): string[] {
  const notes: string[] = [];
  if (system.tags.includes("frontier")) {
    notes.push("▲ Frontier");
  }
  if (system.tags.includes("mining_belt")) {
    notes.push("⛏ Mining");
  }
  if (system.tags.includes("checkpoint") || system.tags.includes("trade_lane")) {
    notes.push("◆ Trade hub");
  }
  if (system.tags.includes("restricted") || system.faction === "unity_church") {
    notes.push("✝ Unity");
  }
  return notes;
}

function formatRisk(chance: number): string {
  if (chance < 0.35) {
    return "Safe";
  }
  if (chance < 0.65) {
    return "Moderate";
  }
  return "Hazardous";
}
