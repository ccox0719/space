import { gameState } from "../core/state";
import { getCurrentShipTemplate, repairShip, refuelShip } from "../systems/shipSystem";
import { getInstalledComponents } from "../systems/componentSystem";
import { getWeaponById } from "../systems/weaponSystem";

declare const nav: (screen: string) => void;

declare global {
  interface Window {
    repairShipAction: () => void;
    refuelShipAction: () => void;
  }
}

window.repairShipAction = () => {
  repairShip();
};

window.refuelShipAction = () => {
  refuelShip();
};

export function ShipScreen(): string {
  const ship = gameState.ship;
  const tpl = getCurrentShipTemplate();
  const comps = getInstalledComponents();
  const cooldowns = gameState.combat?.playerCooldowns ?? [];

  const templateInfo = tpl
    ? `<p class="muted">${tpl.description}</p>`
    : `<p class="muted">Unknown template (${ship.templateId})</p>`;

  const componentsList =
    comps.length === 0
      ? `<p>No components installed.</p>`
      : `<ul>${comps
          .map((c) => `<li>${c.name} (+${c.value} ${c.effectType})</li>`)
          .join("")}</ul>`;

  return `
    <div class="screen ship">
      <h1>Ship: ${ship.name}</h1>
      ${templateInfo}

      <h2>Stats</h2>
      <p>Hull: ${ship.hp}/${ship.maxHp}</p>
      <p>Shields: ${ship.shields}/${ship.maxShields}</p>
      <p>Fuel: ${ship.fuel}/${ship.maxFuel}</p>
      <p>Cargo Capacity: ${ship.cargoCapacity}</p>

      <h2>Installed Components</h2>
      ${componentsList}

      <h2>Weapons</h2>
      <table>
        <thead>
          <tr><th>Slot</th><th>Hardpoint</th><th>Weapon</th><th>Cooldown</th></tr>
        </thead>
        <tbody>
          ${ship.hardpoints
            .map((hp, idx) => {
              const weapon = getWeaponById(ship.weapons[idx]);
              const name = weapon?.name || "Empty";
              const cd = cooldowns[idx] ?? 0;
              return `
                <tr>
                  <td>${idx + 1}</td>
                  <td>${hp.size} ${hp.type}</td>
                  <td>${name}</td>
                  <td>${cd > 0 ? `${cd} turn${cd === 1 ? "" : "s"} left` : "Ready"}</td>
                </tr>
              `;
            })
            .join("") || "<tr><td colspan=\"4\">No hardpoints installed.</td></tr>"}
        </tbody>
      </table>
      <p><a href="javascript:void(0)" onclick="nav('weapon_slots')">Manage Weapons</a></p>

      <h2>Basic Services</h2>
      <ul class="actions">
        <li onclick="repairShipAction()">Repair to Full (1 cr per point)</li>
        <li onclick="refuelShipAction()">Refuel to Full (2 cr per fuel)</li>
        <li onclick="nav('main')">Back to Main</li>
      </ul>
    </div>
  `;
}
