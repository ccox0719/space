import { getEventById, applyConsequence } from "../systems/eventSystem";
import { navigation } from "../core/navigation";
import { startCombat } from "../systems/combatSystem";

declare const nav: (screen: string, params?: Record<string, unknown>) => void;
declare const pickChoice: (choiceIdx: number) => void;

export function EventScreen(params: Record<string, unknown> = {}): string {
  const eventId = typeof params.eventId === "string" ? params.eventId : "";
  const ev = getEventById(eventId);

  if (!ev) {
    return `
      <div class="screen event">
        <h1>No Event</h1>
        <p>No events available here.</p>
        <ul class="actions">
          <li onclick="nav('main')">Back to Main</li>
        </ul>
      </div>
    `;
  }

  const choices = ev.choices
    .map(
      (c, idx) => `
        <li onclick="pickChoice(${idx})">${c.text}</li>
      `
    )
    .join("");

  return `
    <div class="screen event">
      <h1>${ev.title}</h1>
      <p>${ev.description}</p>
      <h3>Choices</h3>
      <ul class="actions">
        ${choices}
      </ul>
      <ul class="actions">
        <li onclick="nav('main')">Back to Main</li>
      </ul>
    </div>
  `;
}

declare global {
  interface Window {
    pickChoice: (choiceIdx: number) => void;
  }
}

window.pickChoice = (choiceIdx: number) => {
  const params = navigation.params;
  const eventId = typeof params.eventId === "string" ? params.eventId : "";
  const ev = getEventById(eventId);
  if (!ev) {
    nav("main");
    return;
  }
  const choice = ev.choices[choiceIdx];
  if (choice) {
    // simple combat hook: if choice text contains "Fight" or consequence has combat marker, route to combat screen
    const combatTarget =
      (choice as any)?.consequence?.combat?.enemyId ||
      (choice.text.toLowerCase().includes("fight") ? "pirate_cutter" : null);

    if (combatTarget) {
      startCombat(combatTarget);
      return;
    }

    applyConsequence(choice);
  }
  nav("main", { message: `Outcome: ${choice?.text || ev.title}` });
};
