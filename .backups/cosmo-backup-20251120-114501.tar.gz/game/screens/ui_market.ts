import { gameState } from "../core/state";
import { getSystemById } from "../core/engine";
import {
  buyCommodity,
  canBuy,
  canSell,
  getAllCommodities,
  getCargoCount,
  getCommodityById,
  getLocalPrice,
  sellCommodity
} from "../systems/economySystem";

declare const nav: (screen: string, params?: Record<string, unknown>) => void;

export function MarketScreen(): string {
  const system = getSystemById(gameState.location.systemId);
  if (!system) {
    return `
      <div class="screen market">
        <h1>Market</h1>
        <p>Loading market data…</p>
        <ul class="actions">
          <li onclick="nav('main')">Back to Main</li>
        </ul>
      </div>
    `;
  }

  const commodities = getAllCommodities();
  if (!commodities.length) {
    return `
      <div class="screen market">
        <h1>Market — ${system.name}</h1>
        <p>No commodities available in this sector yet.</p>
        <ul class="actions">
          <li onclick="nav('main')">Back to Main</li>
        </ul>
      </div>
    `;
  }

  const buyRows =
    commodities
      .map((commodity) => {
        const price = getLocalPrice(system.id, commodity.id);
        const priceLabel = price > 0 ? `${price} cr` : "N/A";
        const tags = commodity.tags.join(", ");
        const disabledAttr = canBuy(system.id, commodity.id, 1) ? "" : " disabled";
        return `
          <tr>
            <td>${commodity.name}</td>
            <td>${priceLabel}</td>
            <td>${tags}</td>
            <td>
              <button${disabledAttr} onclick="buyCommodityAction('${commodity.id}')">
                Buy 1
              </button>
            </td>
          </tr>
        `;
      })
      .join("");

  const sellable = commodities.filter((commodity) => getCargoCount(commodity.id) > 0);
  const sellRows =
    sellable.length > 0
      ? sellable
          .map((commodity) => {
            const price = getLocalPrice(system.id, commodity.id);
            const priceLabel = price > 0 ? `${price} cr` : "N/A";
            const cargoQty = getCargoCount(commodity.id);
            const disabledAttr = canSell(system.id, commodity.id, 1) ? "" : " disabled";
            return `
              <tr>
                <td>${commodity.name}</td>
                <td>${priceLabel}</td>
                <td>${cargoQty}</td>
                <td>
                  <button${disabledAttr} onclick="sellCommodityAction('${commodity.id}')">
                    Sell 1
                  </button>
                </td>
              </tr>
            `;
          })
          .join("")
      : "<tr><td colspan=\"4\">You have nothing to sell.</td></tr>";

  return `
    <div class="screen market">
      <h1>Market — ${system.name}</h1>
      <p id="market-message">
        Credits: ${gameState.player.credits} | Cargo: ${formatCargoSummary()}
      </p>
      <div class="market-section">
        <h2>Buy</h2>
        <table>
          <thead>
            <tr><th>Commodity</th><th>Price</th><th>Tags</th><th>Actions</th></tr>
          </thead>
          <tbody>
            ${buyRows}
          </tbody>
        </table>
      </div>
      <div class="market-section">
        <h2>Sell</h2>
        <table>
          <thead>
            <tr><th>Commodity</th><th>Price</th><th>Held</th><th>Actions</th></tr>
          </thead>
          <tbody>
            ${sellRows}
          </tbody>
        </table>
      </div>
      <ul class="actions">
        <li onclick="nav('main')">Back to Main</li>
      </ul>
    </div>
  `;
}

function formatCargoSummary(): string {
  const cargo = gameState.ship.cargo || {};
  const load = Object.values(cargo).reduce((sum, qty) => sum + qty, 0);
  return `${load}/${gameState.ship.cargoCapacity}`;
}

declare global {
  interface Window {
    buyCommodityAction: (commodityId: string) => void;
    sellCommodityAction: (commodityId: string) => void;
  }
}

window.buyCommodityAction = (commodityId: string) => {
  const systemId = gameState.location.systemId;
  const commodity = getCommodityById(commodityId);
  const success = buyCommodity(systemId, commodityId, 1);
  const price = getLocalPrice(systemId, commodityId);
  const msgEl = document.getElementById("market-message");
  if (msgEl) {
    msgEl.textContent = success
      ? `Bought 1 ${commodity?.name || commodityId} for ${price} cr.`
      : `Cannot buy ${commodity?.name || commodityId}.`;
  }
  nav("market");
};

window.sellCommodityAction = (commodityId: string) => {
  const systemId = gameState.location.systemId;
  const commodity = getCommodityById(commodityId);
  const success = sellCommodity(systemId, commodityId, 1);
  const price = getLocalPrice(systemId, commodityId);
  const msgEl = document.getElementById("market-message");
  if (msgEl) {
    msgEl.textContent = success
      ? `Sold 1 ${commodity?.name || commodityId} for ${price} cr.`
      : `Cannot sell ${commodity?.name || commodityId}.`;
  }
  nav("market");
};
