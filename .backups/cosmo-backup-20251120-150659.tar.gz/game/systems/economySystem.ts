import { gameState } from "../core/state";
import type { GameState } from "../core/state";
import { content, getSystemById } from "../core/engine";
import type { CommodityDef, SystemDef } from "../core/contentTypes";

const MARKET_GLOBAL_MODIFIER = "__global__";
const DEFAULT_SPREAD = { buyMultiplier: 1, sellMultiplier: 0.85 };
const TIER_PRICE_MODIFIERS: Record<string, number> = {
  basic: 0.9,
  standard: 1,
  strategic: 1.2,
  luxury: 1.35
};

export type MarketTrend = "high" | "low" | "stable";

export interface MarketPriceQuote {
  base: number;
  buy: number;
  sell: number;
  high: number;
  low: number;
  trend: MarketTrend;
}

function ensureCargo(): Record<string, number> {
  if (!gameState.ship.cargo) {
    gameState.ship.cargo = {};
  }
  return gameState.ship.cargo;
}

function getCargoLoad(): number {
  const cargo = ensureCargo();
  return Object.values(cargo).reduce((sum, qty) => sum + qty, 0);
}

export function getAllCommodities(): CommodityDef[] {
  return content?.commodities ?? [];
}

export function getCommodityById(id: string): CommodityDef | null {
  const commodities = getAllCommodities();
  return commodities.find((commodity) => commodity.id === id) ?? null;
}

function ensureMarketState(): NonNullable<GameState["marketState"]> {
  if (!gameState.marketState) {
    gameState.marketState = { temporaryModifiers: {} };
  }
  return gameState.marketState;
}

function getTemporaryMarketMultiplier(commodityId: string): number {
  const state = ensureMarketState();
  let multiplier = 1;
  const global = state.temporaryModifiers[MARKET_GLOBAL_MODIFIER];
  if (global) {
    multiplier *= Math.max(0, global.multiplier);
  }
  const specific = state.temporaryModifiers[commodityId];
  if (specific) {
    multiplier *= Math.max(0, specific.multiplier);
  }
  return multiplier;
}

function determineTrend(current: number, reference: number): MarketTrend {
  const safeReference = reference > 0 ? reference : 1;
  const ratio = current / safeReference;
  if (ratio >= 1.15) return "high";
  if (ratio <= 0.85) return "low";
  return "stable";
}

function applyProfileModifiers(system: SystemDef, commodity: CommodityDef): number {
  const profile = system.marketProfile;
  if (!profile) return 1;
  let modifier = 1;
  const isImported = profile.imports?.includes(commodity.id);
  const isExported = profile.exports?.includes(commodity.id);
  if (isImported) modifier *= 1.2;
  if (isExported) modifier *= 0.85;
  if (commodity.legalStatus === "illegal") {
    modifier *= profile.blackMarket ? 1.1 : 1.25;
  } else if (profile.blackMarket) {
    modifier *= 0.95;
  }
  if (typeof profile.taxRate === "number") {
    modifier *= 1 + Math.max(0, profile.taxRate);
  }
  return modifier;
}

function computeBaseLocalPrice(system: SystemDef, commodity: CommodityDef): number {
  const base = Math.max(1, commodity.basePrice);
  const tierModifier = TIER_PRICE_MODIFIERS[commodity.tier ?? "standard"] ?? 1;
  const systemModifier = system.marketModifiers?.[commodity.id] ?? 1;
  const profileModifier = applyProfileModifiers(system, commodity);
  const volatility = Math.min(Math.max(commodity.volatility ?? 0.25, 0), 1);
  const volatilityBoost = 1 + volatility * 0.08;
  const temporary = getTemporaryMarketMultiplier(commodity.id);
  const price = base * tierModifier * systemModifier * profileModifier * volatilityBoost * temporary;
  return Math.max(1, Math.round(price));
}

export function getLocalPrice(systemId: string, commodityId: string): number {
  const quote = getBuySellPrices(systemId, commodityId);
  return quote.base;
}

export function getBuySellPrices(systemId: string, commodityId: string): MarketPriceQuote {
  const system = getSystemById(systemId);
  const commodity = getCommodityById(commodityId);
  if (!system || !commodity) {
    return {
      base: 0,
      buy: 0,
      sell: 0,
      high: 0,
      low: 0,
      trend: "stable"
    };
  }

  const basePrice = computeBaseLocalPrice(system, commodity);
  const spread = commodity.baseSpread ?? DEFAULT_SPREAD;
  const volatility = Math.min(Math.max(commodity.volatility ?? 0.25, 0), 1);
  const buy = Math.max(
    1,
    Math.round(basePrice * (spread.buyMultiplier ?? 1) * (1 + volatility * 0.05))
  );
  const sell = Math.max(
    1,
    Math.round(basePrice * (spread.sellMultiplier ?? 0.85) * Math.max(0.6, 1 - volatility * 0.05))
  );
  const high = Math.max(buy, sell, Math.round(basePrice * (1 + volatility * 0.1)));
  const low = Math.max(
    1,
    Math.min(
      buy,
      sell,
      Math.round(basePrice * Math.max(0.65, 1 - volatility * 0.2))
    )
  );
  const trend = determineTrend(basePrice, commodity.basePrice);

  return { base: basePrice, buy, sell, high, low, trend };
}

export function applyTemporaryMarketModifier(
  commodityId: string | null | undefined,
  multiplier: number,
  duration: number = 2
): void {
  const state = ensureMarketState();
  const key = commodityId && commodityId.length ? commodityId : MARKET_GLOBAL_MODIFIER;
  state.temporaryModifiers[key] = {
    multiplier: Math.max(0, multiplier),
    remainingTurns: Math.max(1, Math.floor(duration))
  };
}

export function tickMarket(turns: number = 1): void {
  if (turns <= 0) return;
  const state = ensureMarketState();
  const keys = Object.keys(state.temporaryModifiers);
  for (const key of keys) {
    const modifier = state.temporaryModifiers[key];
    modifier.remainingTurns -= turns;
    if (modifier.remainingTurns <= 0) {
      delete state.temporaryModifiers[key];
    }
  }
}

export function getCargoCount(commodityId: string): number {
  const cargo = ensureCargo();
  return cargo[commodityId] ?? 0;
}

export function canBuy(
  systemId: string,
  commodityId: string,
  amount: number
): boolean {
  if (amount <= 0) return false;
  const price = getBuySellPrices(systemId, commodityId).buy;
  if (price <= 0) return false;
  const total = price * amount;
  if (gameState.player.credits < total) return false;
  const capacity = gameState.ship.cargoCapacity;
  if (capacity <= 0) return false;
  return getCargoLoad() + amount <= capacity;
}

export function canSell(
  _systemId: string,
  commodityId: string,
  amount: number
): boolean {
  if (amount <= 0) return false;
  const held = getCargoCount(commodityId);
  return held >= amount;
}

export function buyCommodity(
  systemId: string,
  commodityId: string,
  amount: number
): boolean {
  if (!canBuy(systemId, commodityId, amount)) return false;
  const price = getBuySellPrices(systemId, commodityId).buy;
  const total = price * amount;
  gameState.player.credits -= total;
  const cargo = ensureCargo();
  cargo[commodityId] = (cargo[commodityId] || 0) + amount;
  return true;
}

export function sellCommodity(
  systemId: string,
  commodityId: string,
  amount: number
): boolean {
  if (!canSell(systemId, commodityId, amount)) return false;
  const price = getBuySellPrices(systemId, commodityId).sell;
  const total = price * amount;
  const cargo = ensureCargo();
  cargo[commodityId] = Math.max(0, (cargo[commodityId] || 0) - amount);
  gameState.player.credits += total;
  return true;
}

export function getCargoValue(state: GameState, systemId: string): number {
  const cargo = state.ship.cargo || {};
  return Object.entries(cargo).reduce((sum, [commodityId, qty]) => {
    if (!qty) return sum;
    const price = getBuySellPrices(systemId, commodityId).sell;
    return sum + price * qty;
  }, 0);
}
