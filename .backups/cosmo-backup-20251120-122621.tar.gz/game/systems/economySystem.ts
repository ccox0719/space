import { gameState } from "../core/state";
import { content, getSystemById } from "../core/engine";
import type { CommodityDef } from "../core/contentTypes";

function ensureCargo(): Record<string, number> {
  if (!gameState.ship.cargo) {
    gameState.ship.cargo = {};
  }
  return gameState.ship.cargo;
}

function getCargoLoad(): number {
  const cargo = ensureCargo();
  return Object.values(cargo).reduce((sum, qty) => sum + qty, 0);
}

export function getAllCommodities(): CommodityDef[] {
  return content?.commodities ?? [];
}

export function getCommodityById(id: string): CommodityDef | null {
  const commodities = getAllCommodities();
  return commodities.find((commodity) => commodity.id === id) ?? null;
}

export function getLocalPrice(systemId: string, commodityId: string): number {
  const system = getSystemById(systemId);
  const commodity = getCommodityById(commodityId);
  if (!system || !commodity) return 0;
  const modifier = system.marketModifiers?.[commodityId] ?? 1;
  return Math.max(1, Math.round(commodity.basePrice * modifier));
}

export function getCargoCount(commodityId: string): number {
  const cargo = ensureCargo();
  return cargo[commodityId] ?? 0;
}

export function canBuy(
  systemId: string,
  commodityId: string,
  amount: number
): boolean {
  if (amount <= 0) return false;
  const price = getLocalPrice(systemId, commodityId);
  if (price <= 0) return false;
  const total = price * amount;
  if (gameState.player.credits < total) return false;
  const capacity = gameState.ship.cargoCapacity;
  if (capacity <= 0) return false;
  return getCargoLoad() + amount <= capacity;
}

export function canSell(
  _systemId: string,
  commodityId: string,
  amount: number
): boolean {
  if (amount <= 0) return false;
  const held = getCargoCount(commodityId);
  return held >= amount;
}

export function buyCommodity(
  systemId: string,
  commodityId: string,
  amount: number
): boolean {
  if (!canBuy(systemId, commodityId, amount)) return false;
  const price = getLocalPrice(systemId, commodityId);
  const total = price * amount;
  gameState.player.credits -= total;
  const cargo = ensureCargo();
  cargo[commodityId] = (cargo[commodityId] || 0) + amount;
  return true;
}

export function sellCommodity(
  systemId: string,
  commodityId: string,
  amount: number
): boolean {
  if (!canSell(systemId, commodityId, amount)) return false;
  const price = getLocalPrice(systemId, commodityId);
  const total = price * amount;
  const cargo = ensureCargo();
  cargo[commodityId] = Math.max(0, (cargo[commodityId] || 0) - amount);
  gameState.player.credits += total;
  return true;
}
