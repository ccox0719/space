import { gameState } from "../core/engine";
import { StarSystem } from "./travelSystem";
import { acceptMission, tickMissionTimers } from "./missionSystem";

export interface EventChoice {
  text: string;
  consequence?: {
    creditsDelta?: number;
    fuelDelta?: number;
    cargoGain?: Record<string, number>;
    cargoLoss?: Record<string, number>;
    turnDelta?: number;
    spawnMissionId?: string;
  };
}

export interface GameEvent {
  id: string;
  title: string;
  description: string;
  weight: number;
  tags: string[];
  choices: EventChoice[];
}

let events: GameEvent[] = [];

export function setEvents(data: GameEvent[]): void {
  events = data;
}

export function getEvents(): GameEvent[] {
  return events;
}

export function getEventById(id: string): GameEvent | undefined {
  return events.find((e) => e.id === id);
}

export function pickEvent(system?: StarSystem | null): GameEvent | undefined {
  if (!system) return undefined;
  const weighted = system.eventWeights || {};

  const candidates = events.filter((e) => {
    const weight = weighted[e.id] ?? e.weight ?? 0;
    return weight > 0;
  });

  if (!candidates.length) return undefined;

  const total = candidates.reduce(
    (sum, ev) => sum + (weighted[ev.id] ?? ev.weight ?? 0),
    0
  );
  let roll = Math.random() * total;
  for (const ev of candidates) {
    roll -= weighted[ev.id] ?? ev.weight ?? 0;
    if (roll <= 0) return ev;
  }
  return candidates[0];
}

export function applyConsequence(choice: EventChoice): void {
  const c = choice.consequence;
  if (!c) return;

  if (typeof c.creditsDelta === "number") {
    gameState.player.credits += c.creditsDelta;
    if (gameState.player.credits < 0) gameState.player.credits = 0;
  }

  if (typeof c.fuelDelta === "number") {
    const capacity = gameState.ship.maxFuel;
    gameState.ship.fuel = Math.max(
      0,
      Math.min(capacity, gameState.ship.fuel + c.fuelDelta)
    );
  }

  if (typeof c.turnDelta === "number") {
    gameState.time.turn += c.turnDelta;
    tickMissionTimers();
  }

  if (c.cargoGain) {
    for (const [id, qty] of Object.entries(c.cargoGain)) {
      gameState.ship.cargo[id] = (gameState.ship.cargo[id] || 0) + qty;
    }
  }

  if (c.cargoLoss) {
    for (const [id, qty] of Object.entries(c.cargoLoss)) {
      const current = gameState.ship.cargo[id] || 0;
      gameState.ship.cargo[id] = Math.max(0, current - qty);
    }
  }

  if (typeof c.spawnMissionId === "string") {
    const result = acceptMission(c.spawnMissionId);
    if (result.success) {
      pushNotification(`New mission received: ${c.spawnMissionId}`);
    }
  }
}

function pushNotification(message: string): void {
  gameState.notifications.push(message);
}
