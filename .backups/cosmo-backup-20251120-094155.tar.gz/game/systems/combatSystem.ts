import { gameState } from "../core/engine";
import { navigation } from "../core/navigation";
import { recordCombatKill } from "./missionSystem";

interface EnemyTemplate {
  id: string;
  name: string;
  hp: number;
  shields: number;
  accuracy: number;
  dmgMin: number;
  dmgMax: number;
  canEscape: boolean;
}

const ENEMIES: EnemyTemplate[] = [
  {
    id: "pirate_cutter",
    name: "Pirate Cutter",
    hp: 60,
    shields: 15,
    accuracy: 0.6,
    dmgMin: 6,
    dmgMax: 12,
    canEscape: true
  },
  {
    id: "raider_skiff",
    name: "Raider Skiff",
    hp: 40,
    shields: 10,
    accuracy: 0.5,
    dmgMin: 4,
    dmgMax: 9,
    canEscape: true
  }
];

function getEnemyTemplate(id: string): EnemyTemplate {
  const enemy = ENEMIES.find((e) => e.id === id);
  if (!enemy) {
    throw new Error(`Unknown enemy: ${id}`);
  }
  return enemy;
}

function randBetween(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export type PlayerCombatAction = "attack" | "brace" | "target_engines" | "flee";

export function startCombat(enemyId: string): void {
  const tpl = getEnemyTemplate(enemyId);

  gameState.combat = {
    enemyId: tpl.id,
    enemyName: tpl.name,
    enemyHp: tpl.hp,
    enemyMaxHp: tpl.hp,
    enemyShields: tpl.shields,
    enemyMaxShields: tpl.shields,
    enemyAccuracy: tpl.accuracy,
    enemyDamageMin: tpl.dmgMin,
    enemyDamageMax: tpl.dmgMax,
    canEscape: tpl.canEscape,
    playerBracing: false,
    log: [`${tpl.name} engages you in combat!`]
  };

  navigation.go("combat");
}

function log(line: string): void {
  const c = gameState.combat;
  if (!c) return;
  c.log.push(line);
  if (c.log.length > 10) {
    c.log = c.log.slice(c.log.length - 10);
  }
}

export function playerCombatAction(action: PlayerCombatAction): void {
  const c = gameState.combat;
  if (!c) return;

  c.playerBracing = false;

  switch (action) {
    case "attack":
      playerAttack();
      break;
    case "brace":
      playerBrace();
      break;
    case "target_engines":
      playerTargetEngines();
      break;
    case "flee":
      if (attemptFlee()) return;
      break;
  }

  if (!gameState.combat) return;
  if (c.enemyHp <= 0) {
    handleVictory();
    return;
  }

  enemyTurn();

  if (!gameState.combat) return;
  if (gameState.ship.hp <= 0) {
    handleDefeat();
  }
}

function playerAttack(): void {
  const c = gameState.combat;
  if (!c) return;

  const dmg = randBetween(8, 14);
  let remaining = dmg;
  if (c.enemyShields > 0) {
    const absorbed = Math.min(c.enemyShields, remaining);
    c.enemyShields -= absorbed;
    remaining -= absorbed;
  }
  if (remaining > 0) {
    c.enemyHp = Math.max(0, c.enemyHp - remaining);
  }
  log(`You fire on the ${c.enemyName} for ${dmg} damage.`);
}

function playerBrace(): void {
  const c = gameState.combat;
  if (!c) return;
  c.playerBracing = true;
  log("You divert power to defensive maneuvers, bracing for the next attack.");
}

function playerTargetEngines(): void {
  const c = gameState.combat;
  if (!c) return;

  const hitChance = 0.6;
  const roll = Math.random();

  if (roll <= hitChance) {
    c.enemyAccuracy = Math.max(0, c.enemyAccuracy - 0.15);
    c.canEscape = false;
    log(`You land a precision shot on the ${c.enemyName}'s engines, hampering its maneuvers.`);
  } else {
    log("Your shot at the enemy engines misses.");
  }
}

function attemptFlee(): boolean {
  const c = gameState.combat;
  if (!c) return false;
  if (!c.canEscape) {
    log("The enemy has you locked down. You can't flee right now.");
    return false;
  }

  const baseChance = 0.4;
  const bonus = (gameState.ship.fuel / Math.max(1, gameState.ship.maxFuel)) * 0.2;
  const fleeChance = baseChance + bonus;
  const roll = Math.random();

  if (roll <= fleeChance) {
    log("You punch the drives and break away from combat!");
    gameState.combat = null;
    navigation.go("main", { message: "You fled the engagement." });
    return true;
  } else {
    log("You try to flee, but the enemy pins you down.");
    return false;
  }
}

function enemyTurn(): void {
  const c = gameState.combat;
  if (!c) return;

  const roll = Math.random();
  if (roll <= c.enemyAccuracy) {
    let dmg = randBetween(c.enemyDamageMin, c.enemyDamageMax);
    if (c.playerBracing) {
      dmg = Math.floor(dmg * 0.6);
    }

    let remaining = dmg;
    if (gameState.ship.shields > 0) {
      const absorbed = Math.min(gameState.ship.shields, remaining);
      gameState.ship.shields -= absorbed;
      remaining -= absorbed;
    }
    if (remaining > 0) {
      gameState.ship.hp = Math.max(0, gameState.ship.hp - remaining);
    }
    log(`The ${c.enemyName} hits you for ${dmg} damage.`);
  } else {
    log(`The ${c.enemyName} fires, but misses.`);
  }
}

function handleVictory(): void {
  const c = gameState.combat;
  if (!c) return;

  log(`The ${c.enemyName} breaks apart. You are victorious.`);
  gameState.player.credits += 200;
  log("You salvage 200 credits from the wreck.");
  recordCombatKill(c.enemyId);

  gameState.combat = null;
  navigation.go("main", { message: "Enemy defeated." });
}

function handleDefeat(): void {
  log("Your ship is crippled and you barely escape with your life.");
  gameState.ship.hp = 1;
  gameState.ship.shields = 0;
  gameState.player.wanted = 0;
  gameState.combat = null;
  navigation.go("main", { message: "You were defeated in combat." });
}
