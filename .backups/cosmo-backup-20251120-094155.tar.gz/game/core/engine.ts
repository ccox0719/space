import { newGameState, GameState } from "./state";
import { navigation } from "./navigation";
import { render } from "./renderer";
import { setSystems, StarSystem } from "../systems/travelSystem";
import { setCommodities, Commodity } from "../systems/economySystem";
import { setEvents, GameEvent } from "../systems/eventSystem";
import { setMissions, MissionTemplate } from "../systems/missionSystem";

declare global {
  interface Window {
    nav: (screen: string, params?: Record<string, unknown>) => void;
  }
}

export let gameState: GameState;

export async function initGame() {
  // load content JSON
  const systems = await loadJson<StarSystem[]>("/content/systems.json");
  setSystems(systems);
  const commodities = await loadJson<Commodity[]>("/content/commodities.json");
  setCommodities(commodities);
  const events = await loadJson<GameEvent[]>("/content/events.json");
  setEvents(events);
  const missions = await loadJson<MissionTemplate[]>("/content/missions.json");
  setMissions(missions);

  gameState = newGameState();

  // ensure navigation.go triggers render
  const originalGo = navigation.go.bind(navigation);
  navigation.go = (screen, params) => {
    originalGo(screen, params);
    render();
  };

  // expose a simple global nav helper used by screen HTML
  window.nav = (screen: string, params: Record<string, unknown> = {}) => {
    navigation.go(screen as any, params);
  };

  // initial render
  render();
}

async function loadJson<T>(path: string): Promise<T> {
  const res = await fetch(path);
  if (!res.ok) {
    throw new Error(`Failed to load ${path}: ${res.status}`);
  }
  return res.json() as Promise<T>;
}
