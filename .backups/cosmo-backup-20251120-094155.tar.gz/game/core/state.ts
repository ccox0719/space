export interface LocationState {
  systemId: string;
  docked: boolean;
}

export interface PlayerState {
  name: string;
  credits: number;
  roles: string[];
  wanted: number;
}

export interface ShipState {
  id: string;
  name: string;
  hp: number;
  maxHp: number;
  shields: number;
  maxShields: number;
  fuel: number;
  maxFuel: number;
  cargoCapacity: number;
  cargo: Record<string, number>;
  modules: string[];
  weapons: string[];
  weaponPower: number;
  evasion: number;
}

export interface CombatState {
  enemyId: string;
  enemyName: string;
  enemyHp: number;
  enemyMaxHp: number;
  enemyShields: number;
  enemyMaxShields: number;
  enemyAccuracy: number;
  enemyDamageMin: number;
  enemyDamageMax: number;
  canEscape: boolean;
  playerBracing: boolean;
  log: string[];
}

export interface CrewMember {
  id: string;
  name: string;
  role: string;
  tier: number;
  morale: number;
}

export interface ReputationTrack {
  [factionId: string]: number;
}

export interface ContractState {
  id: string;
  name: string;
  description?: string;
  type: string;
  status: "active" | "completed" | "failed";
  sourceFaction?: string;
  targetSystemId?: string;
  reward?: { credits?: number; rep?: Record<string, number> };
  requirements?: Record<string, unknown>;
  progress?: Record<string, unknown>;
  acceptedTurn?: number;
}

export interface TradeLogEntry {
  action: "buy" | "sell";
  commodityId: string;
  quantity: number;
  price: number;
  systemId: string;
  turn: number;
}

export interface GameState {
  version: number;
  time: { day: number; turn: number };
  location: LocationState;
  player: PlayerState;
  ship: ShipState;
  crew: CrewMember[];
  reputation: ReputationTrack;
  contracts: ContractState[];
  combat: CombatState | null;
  notifications: string[];
  transactions: TradeLogEntry[];
}

export function newGameState(): GameState {
  return {
    version: 1,
    time: { day: 1, turn: 0 },
    location: { systemId: "helion_prime", docked: true },
    player: {
      name: "Captain Vega",
      credits: 1000,
      roles: ["trader"],
      wanted: 0
    },
    ship: {
      id: "light_freighter",
      name: "Wayfarer",
      hp: 100,
      maxHp: 100,
      shields: 40,
      maxShields: 40,
      fuel: 30,
      maxFuel: 50,
      cargoCapacity: 80,
      cargo: {},
      modules: [],
      weapons: ["laser_array"],
      weaponPower: 12,
      evasion: 5
    },
    crew: [
      { id: "crew_pilot", name: "Aela Ren", role: "pilot", tier: 2, morale: 0.85 }
    ],
    reputation: {},
    contracts: [],
    combat: null,
    notifications: [],
    transactions: []
  };
}
