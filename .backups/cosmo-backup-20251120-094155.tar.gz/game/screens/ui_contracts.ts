declare const nav: (screen: string, params?: Record<string, unknown>) => void;

import {
  getAvailableMissions,
  getActiveContracts,
  acceptMission,
  describeMission,
  getMissionProgress
} from "../systems/missionSystem";

declare const nav: (screen: string, params?: Record<string, unknown>) => void;
declare const acceptContract: (missionId: string) => void;

export function ContractsScreen(params: Record<string, unknown> = {}): string {
  const message =
    typeof params.message === "string" ? params.message : "";
  const active = getActiveContracts();
  const available = getAvailableMissions();

  const activeList =
    active.length > 0
      ? active
          .map(
            (mission) => `
              <li>
                <strong>${mission.name}</strong> — ${mission.status}
                <div>${mission.description || ""}</div>
                <div>${describeMission(mission)}</div>
                <div>${getMissionProgress(mission)}</div>
              </li>
            `
          )
          .join("")
      : "<p>No active missions.</p>";

  const availableList =
    available.length > 0
      ? available
          .map(
            (mission) => `
              <li>
                <strong>${mission.name}</strong> (${mission.type})
                <div>${mission.description}</div>
                <div>Reward: ${formatReward(mission.reward)}</div>
                <button onclick="acceptContract('${mission.id}')">Accept</button>
              </li>
            `
          )
          .join("")
      : "<p>No available missions.</p>";

  return `
    <div class="screen contracts">
      <h1>Contracts</h1>
      ${message ? `<p><em>${message}</em></p>` : ""}
      <h2>Active</h2>
      <ul class="actions">${activeList}</ul>
      <h2>Available</h2>
      <ul class="actions">${availableList}</ul>
      <ul class="actions">
        <li onclick="nav('main')">Back to Main</li>
      </ul>
    </div>
  `;
}

function formatReward(
  reward?: { credits?: number; rep?: Record<string, number> }
): string {
  if (!reward) return "None";
  const parts: string[] = [];
  if (reward.credits) parts.push(`${reward.credits} credits`);
  if (reward.rep) {
    const repText = Object.entries(reward.rep)
      .map(([faction, value]) => `${faction} ${value > 0 ? "+" : ""}${value}`)
      .join(", ");
    parts.push(`Rep: ${repText}`);
  }
  return parts.join(" | ") || "None";
}

declare global {
  interface Window {
    acceptContract: (missionId: string) => void;
  }
}

window.acceptContract = (missionId: string) => {
  const result = acceptMission(missionId);
  const message = result.success ? "Mission accepted." : result.reason || "Unable to accept.";
  nav("contracts", { message });
};
