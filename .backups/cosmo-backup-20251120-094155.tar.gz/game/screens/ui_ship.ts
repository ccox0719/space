import { gameState } from "../core/engine";
import { buyFuel } from "../systems/economySystem";

declare const nav: (screen: string, params?: Record<string, unknown>) => void;
declare const repairShip: () => void;
declare const refillShields: () => void;
declare const refillFuel: () => void;

const REPAIR_COST_PER_HP = 4;
const SHIELD_REFILL_COST = 25;
const FUEL_UNIT_COST = 15;

export function ShipScreen(params: Record<string, unknown> = {}): string {
  const ship = gameState.ship;
  const message =
    typeof params.message === "string" ? params.message : "";
  const docked = gameState.location.docked;

  return `
    <div class="screen ship">
      <h1>Ship</h1>
      ${message ? `<p><em>${message}</em></p>` : ""}
      <h2>${ship.name}</h2>
      <p>Status: ${docked ? "Docked" : "In Flight"}</p>
      <p>Hull: ${ship.hp}/${ship.maxHp}</p>
      <p>Shields: ${ship.shields}/${ship.maxShields}</p>
      <p>Fuel: ${ship.fuel}/${ship.maxFuel}</p>
      <p>Weapon Power: ${ship.weaponPower} | Evasion: ${ship.evasion}</p>
      <p>Cargo Capacity: ${getCargoLoad()}/${ship.cargoCapacity}</p>
      ${renderCargoManifest()}

      <h3>Services</h3>
      <button onclick="repairShip()" ${docked ? "" : "disabled"}>Repair Hull (${REPAIR_COST_PER_HP} cr per HP)</button>
      <button onclick="refillShields()" ${docked ? "" : "disabled"}>Recharge Shields (${SHIELD_REFILL_COST} cr)</button>
      <button onclick="refillFuel()" ${docked ? "" : "disabled"}>Buy Fuel (${FUEL_UNIT_COST} cr per unit)</button>

      <ul class="actions">
        <li onclick="nav('main')">Back to Main</li>
      </ul>
    </div>
  `;
}

function getCargoLoad(): number {
  return Object.values(gameState.ship.cargo).reduce((sum, qty) => sum + qty, 0);
}

function renderCargoManifest(): string {
  const entries = Object.entries(gameState.ship.cargo);
  if (!entries.length) {
    return "<p>Cargo hold is empty.</p>";
  }
  const list = entries
    .map(([commodityId, qty]) => `<li>${commodityId}: ${qty}</li>`)
    .join("");
  return `
    <h3>Cargo Manifest</h3>
    <ul class="actions">
      ${list}
    </ul>
  `;
}

declare global {
  interface Window {
    repairShip: () => void;
    refillShields: () => void;
    refillFuel: () => void;
  }
}

window.repairShip = () => {
  if (!gameState.location.docked) {
    nav("ship", { message: "You must be docked to repair." });
    return;
  }
  const ship = gameState.ship;
  const missing = ship.maxHp - ship.hp;
  if (missing <= 0) {
    nav("ship", { message: "Hull already at max." });
    return;
  }
  const affordable = Math.min(missing, Math.floor(gameState.player.credits / REPAIR_COST_PER_HP));
  if (affordable <= 0) {
    nav("ship", { message: "Not enough credits for repairs." });
    return;
  }
  const metalAvailable = gameState.ship.cargo["metal"] || 0;
  if (metalAvailable <= 0) {
    nav("ship", { message: "Need metal to perform repairs." });
    return;
  }
  const usable = Math.min(affordable, metalAvailable);
  if (usable <= 0) {
    nav("ship", { message: "No metal available." });
    return;
  }
  const cost = usable * REPAIR_COST_PER_HP;
  gameState.player.credits -= cost;
  ship.hp += usable;
  gameState.ship.cargo["metal"] = metalAvailable - usable;
  nav("ship", { message: `Repaired ${usable} hull for ${cost} credits (used ${usable} metal).` });
};

window.refillShields = () => {
  if (!gameState.location.docked) {
    nav("ship", { message: "You must be docked to recharge shields." });
    return;
  }
  const ship = gameState.ship;
  if (ship.shields >= ship.maxShields) {
    nav("ship", { message: "Shields already full." });
    return;
  }
  if (gameState.player.credits < SHIELD_REFILL_COST) {
    nav("ship", { message: "Not enough credits." });
    return;
  }
  gameState.player.credits -= SHIELD_REFILL_COST;
  ship.shields = ship.maxShields;
  nav("ship", { message: "Shields recharged." });
};

window.refillFuel = () => {
  if (!gameState.location.docked) {
    nav("ship", { message: "You must be docked to refuel." });
    return;
  }
  if (gameState.player.credits < FUEL_UNIT_COST) {
    nav("ship", { message: "Not enough credits for fuel." });
    return;
  }
  const result = buyFuel(1, FUEL_UNIT_COST);
  const msg = result.success ? "Purchased 1 fuel." : result.reason || "Fuel purchase failed.";
  nav("ship", { message: msg });
};
