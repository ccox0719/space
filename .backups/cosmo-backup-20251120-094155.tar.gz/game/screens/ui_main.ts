import { gameState } from "../core/engine";
import { navigation } from "../core/navigation";
import { getSystemById } from "../systems/travelSystem";
import { startCombat } from "../systems/combatSystem";
import { getReputationSummary } from "../systems/reputationSystem";

declare const nav: (screen: string, params?: Record<string, unknown>) => void;

export function MainScreen(): string {
  const s = gameState;
  const system = getSystemById(s.location.systemId);
  const message =
    typeof navigation.params.message === "string"
      ? navigation.params.message
      : "";
  const notifications = s.notifications.splice(0);

  return `
    <div class="screen main">
      <h1>${system?.name || s.location.systemId}</h1>
      <p>${system?.description || "Unknown space."}</p>
      <p>Day ${s.time.day}, Turn ${s.time.turn}</p>
      <p>Credits: ${s.player.credits}</p>
      <p>Ship: HP ${s.ship.hp}/${s.ship.maxHp} | Shields ${s.ship.shields}/${s.ship.maxShields} | Fuel ${s.ship.fuel}/${s.ship.maxFuel}</p>
      <p>Roles: ${s.player.roles.join(", ")}</p>
      ${renderReputation()}
      ${renderTransactions()}
      ${notifications.map((note) => `<p class="notice">${note}</p>`).join("")}
      ${message ? `<p><em>${message}</em></p>` : ""}

      <h2>Actions</h2>
      <ul class="actions">
        <li onclick="nav('travel')">Travel</li>
        <li onclick="nav('market')">Trade Market</li>
        <li onclick="nav('contracts')">Contracts</li>
        <li onclick="nav('ship')">Ship</li>
        <li onclick="nav('crew')">Crew</li>
        <li onclick="startTestCombat()">Debug: Fight Pirate</li>
      </ul>
    </div>
  `;
}

function getCargoLoad(state: typeof gameState): number {
  return Object.values(state.ship.cargo).reduce((sum, qty) => sum + qty, 0);
}

declare global {
  interface Window {
    startTestCombat: () => void;
  }
}

window.startTestCombat = () => {
  startCombat("pirate_cutter");
};

function renderReputation(): string {
  const summary = getReputationSummary();
  if (!summary.length) {
    return "<p>Reputation: neutral</p>";
  }
  const top = summary.slice(0, 3);
  const text = top.map((entry) => `${entry.factionId}: ${entry.value}`).join(" | ");
  return `<p>Reputation: ${text}</p>`;
}

function renderTransactions(): string {
  if (!gameState.transactions.length) {
    return "<p>No recent trades.</p>";
  }
  const items = gameState.transactions
    .slice(-5)
    .reverse()
    .map(
      (entry) =>
        `<li>Turn ${entry.turn}: ${entry.action} ${entry.quantity} ${entry.commodityId} @ ${entry.price}cr (${entry.systemId})</li>`
    )
    .join("");
  return `
    <h3>Recent Trades</h3>
    <ul class="actions">
      ${items}
    </ul>
  `;
}

declare global {
  interface Window {
    startTestCombat: () => void;
  }
}

window.startTestCombat = () => {
  startCombat("pirate_cutter");
};
