import { gameState } from "../core/engine";
import { getNeighbors, travelTo } from "../systems/travelSystem";

declare const nav: (screen: string, params?: Record<string, unknown>) => void;

export function TravelScreen(params: Record<string, unknown> = {}): string {
  const currentSystemId = gameState.location.systemId;
  const neighbors = getNeighbors(currentSystemId);
  const fuel = gameState.ship.fuel;
  const fuelCost = 1;
  const error = typeof params.error === "string" ? params.error : "";

  const neighborList = neighbors
    .map(
      (n) => `
        <li>
          <strong>${n.name}</strong> — ${n.description}
          <div>
            <button onclick="travel('${n.id}')" ${fuel < fuelCost ? "disabled" : ""}>
              Jump (cost ${fuelCost} fuel)
            </button>
          </div>
        </li>
      `
    )
    .join("") || "<p>No known jump routes.</p>";

  return `
    <div class="screen travel">
      <h1>Travel</h1>
      <p>Fuel: ${fuel} / ${gameState.ship.maxFuel} — Each jump costs ${fuelCost} fuel.</p>
      ${error ? `<p style="color:#ff7373;">${error}</p>` : ""}
      <ul class="actions">
        ${neighborList}
      </ul>
      <ul class="actions">
        <li onclick="nav('main')">Back to Main</li>
      </ul>
    </div>
  `;
}

// expose minimal helpers for inline handlers
declare global {
  interface Window {
    travel: (systemId: string) => void;
  }
}

window.travel = (systemId: string) => {
  travelTo(systemId);
};
