export interface SystemDef {
  id: string;
  name: string;
  description: string;
  security: string;
  faction: string;
  tags: string[];
  neighbors: string[];
  marketModifiers: Record<string, number>;
  eventWeights: Record<string, number>;
}

export interface HardpointDef {
  size: "small" | "medium" | "large";
  type: "energy" | "projectile" | "hybrid";
}

export interface ShipDef {
  id: string;
  name: string;
  description: string;
  roleHint: string;
  starter: boolean;
  cost: number;
  hull: number;
  shields: number;
  fuel: number;
  cargo: number;
  tags: string[];
  hardpoints: HardpointDef[];
}

export interface ComponentDef {
  id: string;
  name: string;
  description: string;
  cost: number;
  effectType: "hull" | "shields" | "fuel" | "cargo";
  value: number;
}

export type WeaponType = "energy" | "projectile" | "hybrid";
export type WeaponSize = "small" | "medium" | "large";
export type WeaponDamageType = "kinetic" | "thermal" | "plasma" | "EM";

export interface WeaponDef {
  id: string;
  name: string;
  description?: string;
  type: WeaponType;
  size: WeaponSize;
  damage: number;
  damageType: WeaponDamageType;
  shieldMod: number;
  armorMod: number;
  accuracy: number;
  critChance: number;
  critMultiplier: number;
  energyCost: number;
  cooldown: number;
  price: number;
  tags: string[];
}

export interface CommodityDef {
  id: string;
  name: string;
  basePrice: number;
  mass: number;
  tags: string[];
}

export interface EnemyDef {
  id: string;
  name: string;
  hull: number;
  shields: number;
  canEscape: boolean;
  weaponIds: string[];
  hardpoints: HardpointDef[];
}

export interface GameContent {
  systems: SystemDef[];
  ships: ShipDef[];
  components: ComponentDef[];
  weapons: WeaponDef[];
  commodities: CommodityDef[];
  enemies: EnemyDef[];
}
