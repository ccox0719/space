import { navigation } from "./navigation";
import { MainScreen } from "../screens/ui_main";
import { TravelScreen } from "../screens/ui_travel";
import { MarketScreen } from "../screens/ui_market";
import { ContractsScreen } from "../screens/ui_contracts";
import { ShipScreen } from "../screens/ui_ship";
import { EventScreen } from "../screens/ui_event";
import { CombatScreen } from "../screens/ui_combat";
import { ShipyardScreen } from "../screens/ui_shipyard";
import { ShipSelectScreen } from "../screens/ui_ship_select";
import { WeaponSlotsScreen } from "../screens/ui_weapon_slots";
import { WeaponSelectScreen } from "../screens/ui_weapon_select";

export function render() {
  const app = document.getElementById("app");
  if (!app) return;

  let html = "";

  switch (navigation.current) {
    case "main":
      html = MainScreen();
      break;
    case "travel":
      html = TravelScreen();
      break;
    case "market":
      html = MarketScreen();
      break;
    case "contracts":
      html = ContractsScreen();
      break;
    case "ship":
      html = ShipScreen();
      break;
    case "event":
      html = EventScreen(navigation.params);
      break;
    case "combat":
      html = CombatScreen(navigation.params);
      break;
    case "weapon_slots":
      html = WeaponSlotsScreen();
      break;
    case "weapon_select":
      html = WeaponSelectScreen(navigation.params);
      break;
    case "shipyard":
      html = ShipyardScreen();
      break;
    case "ship_select":
      html = ShipSelectScreen();
      break;
  }

  app.innerHTML = html;
}
