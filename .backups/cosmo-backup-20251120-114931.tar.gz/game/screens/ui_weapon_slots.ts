import { gameState } from "../core/state";
import { getWeaponById } from "../systems/weaponSystem";

declare const nav: (screen: string, params?: Record<string, unknown>) => void;

export function WeaponSlotsScreen(): string {
  const ship = gameState.ship;
  if (!ship.hardpoints.length) {
    return `
      <div class="screen weapon-slots">
        <h1>Weapon Slots</h1>
        <p>Your current ship has no weapon hardpoints.</p>
        <ul class="actions">
          <li onclick="nav('ship')">Back to Ship</li>
        </ul>
      </div>
    `;
  }

  const rows = ship.hardpoints
    .map((hp, idx) => {
      const weapon = getWeaponById(ship.weapons[idx]);
      const name = weapon?.name || "Empty";
      return `
        <tr>
          <td>Slot ${idx + 1}</td>
          <td>${hp.size} ${hp.type}</td>
          <td>${name}</td>
          <td>
            <button onclick="nav('weapon_select', { slotIndex: ${idx} })">
              Equip
            </button>
          </td>
        </tr>
      `;
    })
    .join("");

  return `
    <div class="screen weapon-slots">
      <h1>Weapon Hardpoints</h1>
      <table>
        <thead>
          <tr><th>Slot</th><th>Hardpoint</th><th>Weapon</th><th>Action</th></tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>
      <ul class="actions">
        <li onclick="nav('ship')">Back to Ship</li>
      </ul>
    </div>
  `;
}
