import { gameState } from "../core/state";
import { navigation } from "../core/navigation";
import { content } from "../core/engine";
import { computeWeaponDamage, getWeaponById } from "./weaponSystem";

function getEnemyTemplate(id: string) {
  if (!content) {
    throw new Error("Content has not been loaded.");
  }
  const tpl = content.enemies.find((e) => e.id === id);
  if (!tpl) {
    throw new Error(`Unknown enemy template: ${id}`);
  }
  return tpl;
}

function randBetween(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export interface CombatState {
  enemyId: string;
  enemyName: string;
  enemyHp: number;
  enemyMaxHp: number;
  enemyShields: number;
  enemyMaxShields: number;
  enemyWeapons: string[];
  enemyCooldowns: number[];
  playerCooldowns: number[];
  playerBracing: boolean;
  canEscape: boolean;
  round: number;
  log: string[];
}

declare module "../core/state" {
  interface GameState {
    combat?: CombatState | null;
  }
}

function log(line: string) {
  const state = gameState.combat;
  if (!state) return;
  state.log.push(line);
  const MAX_LOG = 10;
  if (state.log.length > MAX_LOG) {
    state.log = state.log.slice(state.log.length - MAX_LOG);
  }
}

export function startCombat(enemyId: string) {
  const tpl = getEnemyTemplate(enemyId);
  const shipWeapons = gameState.ship.weapons;
  const playerCooldowns = shipWeapons.map(() => 0);
  const enemyWeapons = tpl.weaponIds.slice();
  const enemyCooldowns = enemyWeapons.map(() => 0);

  const state: CombatState = {
    enemyId: tpl.id,
    enemyName: tpl.name,
    enemyHp: tpl.hull,
    enemyMaxHp: tpl.hull,
    enemyShields: tpl.shields,
    enemyMaxShields: tpl.shields,
    enemyWeapons,
    enemyCooldowns,
    playerCooldowns,
    playerBracing: false,
    canEscape: tpl.canEscape,
    round: 1,
    log: [`${tpl.name} engages you in combat!`]
  };

  gameState.combat = state;
  navigation.go("combat");
}

export type PlayerCombatActionType = "fire" | "brace" | "flee";

export function playerCombatAction(action: PlayerCombatActionType, weaponIndex?: number) {
  const combat = gameState.combat;
  if (!combat) return;

  combat.playerBracing = false;

  switch (action) {
    case "fire":
      if (weaponIndex === undefined) {
        log("You must choose a weapon to fire.");
        return;
      }
      playerFireWeapon(weaponIndex);
      break;
    case "brace":
      playerBrace();
      break;
    case "flee":
      if (attemptFlee()) {
        return;
      }
      break;
  }

  if (!gameState.combat) return;
  if (combat.enemyHp <= 0) {
    handleVictory();
    return;
  }

  enemyTurn();

  if (!gameState.combat) return;
  if (gameState.ship.hp <= 0) {
    handleDefeat();
    return;
  }

  tickCooldowns();
  combat.round += 1;
}

function playerFireWeapon(slotIndex: number) {
  const combat = gameState.combat;
  if (!combat) return;

  const ship = gameState.ship;
  if (slotIndex < 0 || slotIndex >= ship.weapons.length) {
    log("Invalid weapon slot.");
    return;
  }
  const weaponId = ship.weapons[slotIndex];
  if (!weaponId) {
    log("That hardpoint is empty.");
    return;
  }

  const weapon = getWeaponById(weaponId);
  if (!weapon) {
    log("Missing weapon data.");
    return;
  }

  const cooldown = combat.playerCooldowns[slotIndex] ?? 0;
  if (cooldown > 0) {
    log(`${weapon.name} is still recharging (${cooldown} turn${cooldown === 1 ? "" : "s"}).`);
    return;
  }

  const targetState = {
    shields: combat.enemyShields,
    hp: combat.enemyHp
  };
  const damage = computeWeaponDamage(weapon, targetState);

  if (damage <= 0) {
    log(`You fire ${weapon.name}, but it misses the ${combat.enemyName}.`);
    combat.playerCooldowns[slotIndex] = weapon.cooldown;
    return;
  }

  let remaining = damage;
  if (combat.enemyShields > 0) {
    const absorbed = Math.min(combat.enemyShields, remaining);
    combat.enemyShields -= absorbed;
    remaining -= absorbed;
  }
  if (remaining > 0) {
    combat.enemyHp = Math.max(0, combat.enemyHp - remaining);
  }

  log(`You strike the ${combat.enemyName} with ${weapon.name} for ${damage} damage.`);
  combat.playerCooldowns[slotIndex] = weapon.cooldown;
}

function playerBrace() {
  const combat = gameState.combat;
  if (!combat) return;
  combat.playerBracing = true;
  log("You brace for impact, diverting power to shields and hull integrity.");
}

function attemptFlee(): boolean {
  const combat = gameState.combat;
  if (!combat) return false;
  if (!combat.canEscape) {
    log("The enemy objectives lock you in place. Flee attempt denied.");
    return false;
  }
  const chance = 0.5;
  if (Math.random() <= chance) {
    log("You punch the thrusters and break free of the engagement!");
    gameState.combat = null;
    navigation.go("main");
    return true;
  } else {
    log("You attempt to flee, but the enemy holds you in their sights.");
    return false;
  }
}

function enemyTurn() {
  const combat = gameState.combat;
  if (!combat) return;

  const readySlots: number[] = [];
  combat.enemyWeapons.forEach((id, idx) => {
    const cd = combat.enemyCooldowns[idx] ?? 0;
    if (id && cd <= 0) {
      readySlots.push(idx);
    }
  });

  if (readySlots.length === 0) {
    log(`The ${combat.enemyName} reloads while you advance.`);
    return;
  }

  const slot = readySlots[randBetween(0, readySlots.length - 1)];
  const weaponId = combat.enemyWeapons[slot];
  const weapon = getWeaponById(weaponId);
  if (!weapon) {
    log(`The ${combat.enemyName} fumbles its weapon.`);
    return;
  }

  const targetState = {
    shields: gameState.ship.shields,
    hp: gameState.ship.hp
  };
  let damage = computeWeaponDamage(weapon, targetState);

  if (damage <= 0) {
    log(`The ${combat.enemyName} fires ${weapon.name}, but misses.`);
    combat.enemyCooldowns[slot] = weapon.cooldown;
    return;
  }

  if (combat.playerBracing) {
    damage = Math.round(damage * 0.6);
  }

  let remaining = damage;
  if (gameState.ship.shields > 0) {
    const absorbed = Math.min(gameState.ship.shields, remaining);
    gameState.ship.shields -= absorbed;
    remaining -= absorbed;
  }
  if (remaining > 0) {
    gameState.ship.hp = Math.max(0, gameState.ship.hp - remaining);
  }

  log(`The ${combat.enemyName} hits you with ${weapon.name} for ${damage} damage.`);
  combat.enemyCooldowns[slot] = weapon.cooldown;
}

function tickCooldowns() {
  const combat = gameState.combat;
  if (!combat) return;
  combat.playerCooldowns = combat.playerCooldowns.map((cd) => (cd > 0 ? cd - 1 : 0));
  combat.enemyCooldowns = combat.enemyCooldowns.map((cd) => (cd > 0 ? cd - 1 : 0));
}

function handleVictory() {
  const combat = gameState.combat;
  if (!combat) return;
  log(`The ${combat.enemyName} explodes under your punishing fire. Victory is yours.`);
  const reward = 200;
  gameState.player.credits += reward;
  log(`You salvage ${reward} credits from the wreckage.`);
  gameState.combat = null;
  navigation.go("main");
}

function handleDefeat() {
  log("Your ship is crippled. Systems fail one by one as you drift through vacuum...");
  gameState.ship.hp = 1;
  gameState.ship.shields = 0;
  gameState.combat = null;
  navigation.go("main");
}
