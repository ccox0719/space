import { gameState, persistLoadout } from "../core/state";
import { content, WeaponDef } from "../core/engine";

/**
 * Get all available weapons (raw data).
 */
export function getAllWeapons(): WeaponDef[] {
  if (!content) return [];
  return content.weapons;
}

/**
 * Player's equipped weapons (by hardpoint index).
 */
export function getEquippedWeapons(): (WeaponDef | null)[] {
  if (!content) return [];
  const ship = gameState.ship;
  return ship.weapons.map((id) => content.weapons.find((w) => w.id === id) || null);
}

function ensureInventory() {
  if (!gameState.inventory) {
    gameState.inventory = { weapons: [] };
  }
  return gameState.inventory;
}

export function getInventoryWeaponIds(): string[] {
  const inventory = ensureInventory();
  return [...inventory.weapons];
}

/**
 * Validate compatibility: size & type must match hardpoint.
 */
export function canEquipWeapon(hardpointIndex: number, weaponId: string): boolean {
  const ship = gameState.ship;
  const weapon = content?.weapons.find((w) => w.id === weaponId);
  if (!weapon) return false;

  const hardpoint = ship.hardpoints[hardpointIndex];
  if (!hardpoint) return false;

  return weapon.size === hardpoint.size && weapon.type === hardpoint.type;
}

/**
 * Equip weapon into a slot.
 */
export function equipWeapon(hardpointIndex: number, weaponId: string): boolean {
  if (!canEquipWeapon(hardpointIndex, weaponId)) return false;

  gameState.ship.weapons[hardpointIndex] = weaponId;
  persistLoadout();
  return true;
}

export function getWeaponById(weaponId: string | null): WeaponDef | null {
  if (!weaponId || !content) return null;
  return content.weapons.find((w) => w.id === weaponId) ?? null;
}

export function buyWeapon(weaponId: string): boolean {
  const weapon = getWeaponById(weaponId);
  if (!weapon) return false;
  if (gameState.player.credits < weapon.price) return false;
  const inventory = ensureInventory();
  inventory.weapons.push(weaponId);
  gameState.player.credits -= weapon.price;
  persistLoadout();
  return true;
}
/**
 * Damage calculation for combat.
 */
export function computeWeaponDamage(weapon: WeaponDef, enemyState: { shields: number; hp: number }): number {
  let dmg = weapon.damage;

  // conditional shield/hull mods
  if (enemyState.shields > 0) dmg *= weapon.shieldMod;
  else dmg *= weapon.armorMod;

  // accuracy roll
  if (Math.random() > weapon.accuracy) return 0;

  // critical hit
  if (Math.random() < weapon.critChance) dmg *= weapon.critMultiplier;

  return Math.round(dmg);
}
