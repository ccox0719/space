export interface TimeState {
  day: number;
  turn: number;
}

export interface LocationState {
  systemId: string;
  docked: boolean;
}

export interface PlayerState {
  credits: number;
  roles: string[];
  wanted: number;
  hasChosenStarter: boolean;
}

import shipsData from "../content/ships.json";
import type { ShipDef } from "./contentTypes";

const shipsCatalog = shipsData as ShipDef[];
const starterTemplate = shipsCatalog.find((ship) => ship.starter) ?? shipsCatalog[0];
const starterHardpoints = starterTemplate?.hardpoints.length ?? 0;

export interface ShipState {
  templateId: string;
  name: string;
  hp: number;
  maxHp: number;
  shields: number;
  maxShields: number;
  fuel: number;
  maxFuel: number;
  cargoCapacity: number;
  cargo: Record<string, number>;
  modules: string[];
  weapons: (string | null)[];
  weaponPower: number;
  evasion: number;
  maneuverRating: number;
  components: string[];
  hardpoints: {
    size: "small" | "medium" | "large";
    type: "energy" | "projectile" | "missile" | "hybrid";
  }[];
}

export interface CombatState {
  enemyId: string;
  enemyName: string;
  enemyHp: number;
  enemyMaxHp: number;
  enemyShields: number;
  enemyMaxShields: number;
  enemyWeapons: string[];
  enemyCooldowns: number[];
  playerCooldowns: number[];
  playerBracing: boolean;
  playerStance: "assault" | "balanced" | "evasive";
  playerStatus: {
    maneuverBonus: number;
    maneuverTurns: number;
    shieldBoost: number;
    shieldTurns: number;
  };
  enemyStatus: {
    weaponJammedTurns: number;
  };
  canEscape: boolean;
  totalRounds: number;
  startingHp: number;
  round: number;
  log: string[];
  adviceToken?: number;
}

export interface ReputationTrack {
  [factionId: string]: number;
}

export interface ContractState {
  id: string;
  name: string;
  description?: string;
  type: string;
  status: "active" | "completed" | "failed";
  sourceFaction?: string;
  targetSystemId?: string;
  reward?: { credits?: number; rep?: Record<string, number> };
  requirements?: Record<string, unknown>;
  progress?: Record<string, unknown>;
  acceptedTurn?: number;
}

export interface TradeLogEntry {
  action: "buy" | "sell";
  commodityId: string;
  quantity: number;
  price: number;
  systemId: string;
  turn: number;
}

export interface GameState {
  version: number;
  time: TimeState;
  location: LocationState;
  player: PlayerState;
  ship: ShipState;
  reputation: ReputationTrack;
  contracts: ContractState[];
  combat: CombatState | null;
  notifications: string[];
  transactions: TradeLogEntry[];
  inventory: {
    weapons: string[];
  };
  lastBattleResult?: import("./contentTypes").BattleResult | null;
}

export let gameState: GameState;

const LOADOUT_KEY = "cosmo_weapon_loadout";

export function loadPersistedLoadout(): { weapons: (string | null)[]; inventory: string[] } | null {
  if (typeof window === "undefined" || !window.localStorage) return null;
  const raw = window.localStorage.getItem(LOADOUT_KEY);
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw);
    return {
      weapons: Array.isArray(parsed.weapons) ? parsed.weapons : [],
      inventory: Array.isArray(parsed.inventory) ? parsed.inventory : []
    };
  } catch {
    return null;
  }
}

export function persistLoadout(): void {
  if (typeof window === "undefined" || !window.localStorage) return;
  const payload = {
    weapons: gameState.ship.weapons,
    inventory: gameState.inventory?.weapons ?? []
  };
  window.localStorage.setItem(LOADOUT_KEY, JSON.stringify(payload));
}

export function newGameState(): GameState {
  return {
    version: 1,
    time: { day: 1, turn: 0 },
    location: { systemId: "helion_prime", docked: true },
    player: {
      credits: 1000,
      roles: ["trader"],
      wanted: 0,
      hasChosenStarter: false
    },
    ship: {
      templateId: starterTemplate?.id ?? "none",
      name: starterTemplate?.name ?? "Undefined Hull",
      hp: starterTemplate?.hull ?? 0,
      maxHp: starterTemplate?.hull ?? 0,
      shields: starterTemplate?.shields ?? 0,
      maxShields: starterTemplate?.shields ?? 0,
      fuel: starterTemplate?.fuel ?? 0,
      maxFuel: starterTemplate?.fuel ?? 0,
      cargoCapacity: starterTemplate?.cargo ?? 0,
      cargo: {},
      modules: [],
      weapons: Array(starterHardpoints).fill(null),
      weaponPower: 12,
      evasion: 5,
      maneuverRating: starterTemplate?.maneuverRating ?? 0,
      components: [],
      hardpoints: starterTemplate?.hardpoints.map((hp) => ({ ...hp })) ?? []
    },
    reputation: {},
    contracts: [],
    combat: null,
    notifications: [],
    transactions: [],
    inventory: {
      weapons: ["laser_mk1"]
    },
    lastBattleResult: null
  };
}

export function setGameState(state: GameState) {
  gameState = state;
}
