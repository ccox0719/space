import { gameState } from "../core/state";
import { navigation } from "../core/navigation";
import { systemHasTag } from "../systems/systemHelpers";
import { startCombat } from "../systems/combatSystem";

declare global {
  interface Window {
    nav: (screen: string, params?: Record<string, unknown>) => void;
    devCombat?: (enemyId?: string) => void;
  }
}

window.nav = (screen: string, params: Record<string, unknown> = {}) => {
  navigation.go(screen as any, params);
};
window.devCombat = (enemyId = "pirate_cutter") => {
  startCombat(enemyId);
};

export function MainScreen(): string {
  const s = gameState;

  return `
    <div class="screen main">
      <h1>System: ${s.location.systemId}</h1>
      <p>Day ${s.time.day}, Turn ${s.time.turn}</p>
      <p>Credits: ${s.player.credits}</p>
      <p>Roles: ${s.player.roles.join(", ")} | Wanted: ${s.player.wanted}</p>

      <h2>Ship Status</h2>
      <p>Ship: ${s.ship.name}</p>
      <p>Hull: ${s.ship.hp}/${s.ship.maxHp} | Shields: ${s.ship.shields}/${s.ship.maxShields}</p>
      <p>Fuel: ${s.ship.fuel}/${s.ship.maxFuel} | Cargo Cap: ${s.ship.cargoCapacity}</p>

      <h2>Actions</h2>
      <ul class="actions">
        <li onclick="nav('travel')">Travel</li>
        <li onclick="nav('market')">Trade Market</li>
        <li onclick="nav('contracts', { source: 'main_menu' })">Contracts</li>
        <li onclick="nav('ship')">Ship</li>
        ${systemHasTag(s.location.systemId, "shipyard")
          ? `<li onclick="nav('shipyard')">Shipyard</li>`
          : ``}
        <li onclick="devCombat()">DEV: Start Combat (pirate cutter)</li>
      </ul>
    </div>
  `;
}
