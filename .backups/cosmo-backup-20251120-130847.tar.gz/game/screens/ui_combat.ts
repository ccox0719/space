import { gameState } from "../core/state";
import {
  playerCombatAction,
  setPlayerStance,
  CALLED_SHOT_TIP,
  BRACE_TIP,
  DAMAGE_TYPE_GUIDE,
  getCombatAdvice
} from "../systems/combatSystem";
import { getWeaponById } from "../systems/weaponSystem";

declare const nav: (screen: string, params?: Record<string, unknown>) => void;

declare global {
  interface Window {
    fireWeapon: (slotIndex: number, aimMode?: "normal" | "called_shot") => void;
    brace: () => void;
    flee: () => void;
    setStance: (stance: "assault" | "balanced" | "evasive") => void;
  }
}

window.fireWeapon = (slotIndex: number, aimMode: "normal" | "called_shot" = "normal") => {
  playerCombatAction("fire", slotIndex, aimMode);
  if (gameState.combat) {
    nav("combat");
  }
};

window.brace = () => {
  playerCombatAction("brace");
  if (gameState.combat) {
    nav("combat");
  }
};

window.flee = () => {
  playerCombatAction("flee");
  if (gameState.combat) {
    nav("combat");
  }
};

window.setStance = (stance: "assault" | "balanced" | "evasive") => {
  setPlayerStance(stance);
  if (gameState.combat) {
    nav("combat");
  }
};

export function CombatScreen(): string {
  const c = gameState.combat;

  if (!c) {
    return `
      <div class="screen combat">
        <h1>No Active Combat</h1>
        <p>You are not currently engaged in combat.</p>
        <ul class="actions">
          <li onclick="nav('main')">Back to Main</li>
        </ul>
      </div>
    `;
  }

  const ship = gameState.ship;
  const logHtml = c.log.map((line) => `<div class="log-line">${line}</div>`).join("");

  const weaponRows = ship.hardpoints
    .map((hp, idx) => {
      const weaponId = ship.weapons[idx];
      const weapon = getWeaponById(weaponId);
      const cooldown = c.playerCooldowns[idx] ?? 0;
      const ready = Boolean(weapon) && cooldown === 0;
      return `
        <tr>
          <td>Slot ${idx + 1}</td>
          <td>${hp.size.charAt(0).toUpperCase() + hp.size.slice(1)} ${hp.type}</td>
          <td>${weapon?.name || "Empty"}</td>
          <td>${cooldown > 0 ? `Cooling (${cooldown})` : "Ready"}</td>
          <td>
            <button ${ready ? "" : "disabled"} onclick="fireWeapon(${idx}, 'normal')">
              Fire (Normal)
            </button>
            <button ${ready ? "" : "disabled"} onclick="fireWeapon(${idx}, 'called_shot')">
              Fire (Called Shot)
            </button>
          </td>
        </tr>
      `;
    })
    .join("");

  const damageTypeRows = DAMAGE_TYPE_GUIDE.map(
    (entry) => `
        <tr>
          <td>${entry.type}</td>
          <td>${entry.shieldMultiplier.toFixed(2)}x</td>
          <td>${entry.hullMultiplier.toFixed(2)}x</td>
          <td>${entry.description}</td>
        </tr>
      `
  ).join("");

  const advice = getCombatAdvice();
  const adviceHtml = advice
    ? `<p class="combat-advice ${advice.suggestion}">
        ${advice.text}
        <span class="advice-confidence">Intel confidence: ${(advice.confidence * 100).toFixed(0)}%</span>
      </p>`
    : `<p class="combat-advice">No immediate cues.</p>`;

  const calledShotReady = c.enemyShields <= 0;
  const calledShotHint = calledShotReady
    ? "Shields are down—called shots will score more consistently. Aim for the hull!"
    : "Called shots trade accuracy; wait until shields drop for the best payout.";

  return `
    <div class="screen combat">
      <h1>Combat: ${c.enemyName} (Round ${c.round})</h1>
      <p>Current stance: <strong>${c.playerStance}</strong></p>

      <div class="combat-status">
        <h2>Your Ship</h2>
        <p>HP: ${ship.hp}/${ship.maxHp}</p>
        <p>Shields: ${ship.shields}/${ship.maxShields}</p>
        <p>Fuel: ${ship.fuel}/${ship.maxFuel}</p>
      </div>

      <div class="combat-status">
        <h2>Enemy</h2>
        <p>HP: ${c.enemyHp}/${c.enemyMaxHp}</p>
        <p>Shields: ${c.enemyShields}/${c.enemyMaxShields}</p>
      </div>

      <h2>Weapon Slots</h2>
      <table>
        <thead>
          <tr><th>Slot</th><th>Hardpoint</th><th>Weapon</th><th>Cooldown</th><th>Action</th></tr>
        </thead>
        <tbody>
          ${weaponRows}
        </tbody>
      </table>

      <h2>Stances</h2>
      ${adviceHtml}
      <ul class="actions">
        <li onclick="setStance('assault')">Assault (+15% dmg, +10% dmg taken)</li>
        <li onclick="setStance('balanced')">Balanced (normal)</li>
        <li onclick="setStance('evasive')">Evasive (-20% dmg, -30% dmg taken, better flee)</li>
      </ul>

      <h2>Actions</h2>
      <ul class="actions">
        <li onclick="brace()">Brace</li>
        <li onclick="flee()">Attempt Flee</li>
      </ul>
      <p class="called-shot-hint">${calledShotHint}</p>

      <h2>Combat Guide</h2>
      <div class="combat-guide">
        <p><strong>Called Shot</strong>: ${CALLED_SHOT_TIP}</p>
        <p><strong>Brace vs Attack</strong>: ${BRACE_TIP} Attack to pressure cooldowns, brace when the enemy readies a heavy volley.</p>
        <table class="damage-guide">
          <thead>
            <tr><th>Damage Type</th><th>Shield Effect</th><th>Hull Effect</th><th>Usage Tip</th></tr>
          </thead>
          <tbody>
            ${damageTypeRows}
          </tbody>
        </table>
      </div>

      <h2>Battle Log</h2>
      <div class="combat-log">
        ${logHtml}
      </div>
    </div>
  `;
}
