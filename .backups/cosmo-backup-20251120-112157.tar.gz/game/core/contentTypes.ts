export interface SystemDef {
  id: string;
  name: string;
  description: string;
  security: string;
  faction: string;
  tags: string[];
  neighbors: string[];
  marketModifiers: Record<string, number>;
  eventWeights: Record<string, number>;
}

export interface ShipDef {
  id: string;
  name: string;
  description: string;
  roleHint: string;
  starter: boolean;
  cost: number;
  hull: number;
  shields: number;
  fuel: number;
  cargo: number;
  tags: string[];
}

export interface ComponentDef {
  id: string;
  name: string;
  description: string;
  cost: number;
  effectType: "hull" | "shields" | "fuel" | "cargo";
  value: number;
}

export interface WeaponDef {
  id: string;
  name: string;
  description?: string;
  cooldown: number;
  accuracy: number;
  damageMin: number;
  damageMax: number;
}

export interface CommodityDef {
  id: string;
  name: string;
  basePrice: number;
  mass: number;
  tags: string[];
}

export interface GameContent {
  systems: SystemDef[];
  ships: ShipDef[];
  components: ComponentDef[];
  weapons: WeaponDef[];
  commodities: CommodityDef[];
}
