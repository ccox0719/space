import { WeaponDef } from "../core/engine";

interface WeaponTargetState {
  shields: number;
  hp: number;
}

function randBetween(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Compute the damage a weapon does to a target. Currently only checks for accuracy
 * and returns a random amount between damageMin and damageMax.
 */
export function computeWeaponDamage(
  weapon: WeaponDef,
  targetState: WeaponTargetState
): number {
  const accuracy = Math.min(Math.max(weapon.accuracy ?? 0, 0), 1);
  if (Math.random() > accuracy) {
    return 0;
  }

  const min = Math.min(weapon.damageMin, weapon.damageMax);
  const max = Math.max(weapon.damageMin, weapon.damageMax);
  let damage = randBetween(min, max);

  // Optional future hooks: adjust damage based on shields or target size.
  if (targetState.shields <= 0 && damage > 0) {
    // Slight bonus for hitting hull only.
    damage += Math.round(damage * 0.1);
  }

  return damage;
}
