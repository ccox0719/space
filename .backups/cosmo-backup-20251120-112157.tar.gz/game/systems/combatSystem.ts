// systems/combatSystem.ts
//
// Full tactical combat system using weapon hardpoints.
// - Player and enemy both use WeaponDef from content.weapons
// - Supports cooldowns, brace, flee
// - Keeps a rolling combat log for the UI

import { gameState, CombatState } from "../core/state";
import { navigation } from "../core/navigation";
import { content, WeaponDef } from "../core/engine";
import { computeWeaponDamage } from "../systems/weaponSystem";

/**
 * Simple enemy ship template for now.
 * Later you can move this into content/enemies.json.
 */
interface EnemyTemplate {
  id: string;
  name: string;
  hull: number;
  shields: number;
  canEscape: boolean;
  weaponIds: string[]; // weapon ids from weapons.json
}

// TODO: Move to JSON later if you want.
const ENEMIES: EnemyTemplate[] = [
  {
    id: "pirate_cutter",
    name: "Pirate Cutter",
    hull: 80,
    shields: 25,
    canEscape: true,
    weaponIds: ["laser_mk1"]
  },
  {
    id: "raider_skiff",
    name: "Raider Skiff",
    hull: 60,
    shields: 15,
    canEscape: true,
    weaponIds: ["laser_mk1", "ion_disruptor"]
  }
];

function getEnemyTemplate(id: string): EnemyTemplate {
  const tpl = ENEMIES.find(e => e.id === id);
  if (!tpl) {
    throw new Error(`Unknown enemy template: ${id}`);
  }
  return tpl;
}

function randBetween(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Helper: get a WeaponDef by id.
 */
function getWeaponDef(id: string | null | undefined): WeaponDef | null {
  if (!id || !content) return null;
  return content.weapons.find(w => w.id === id) ?? null;
}

/**
 * Helper: append to combat log, keep last N entries.
 */
function log(line: string) {
  const c = gameState.combat;
  if (!c) return;
  c.log.push(line);
  const MAX_LOG = 10;
  if (c.log.length > MAX_LOG) {
    c.log = c.log.slice(c.log.length - MAX_LOG);
  }
}

/**
 * Initialize combat vs a given enemy template.
 * Called from events/travel/etc.
 */
export function startCombat(enemyId: string) {
  const tpl = getEnemyTemplate(enemyId);

  // Ensure player weapon cooldowns align with weapon slots
  const playerWeapons = gameState.ship.weapons || [];
  const playerCooldowns = playerWeapons.map(() => 0);

  const enemyWeapons = tpl.weaponIds.slice();
  const enemyCooldowns = enemyWeapons.map(() => 0);

  const state: CombatState = {
    enemyId: tpl.id,
    enemyName: tpl.name,
    enemyHp: tpl.hull,
    enemyMaxHp: tpl.hull,
    enemyShields: tpl.shields,
    enemyMaxShields: tpl.shields,
    enemyWeapons,
    enemyCooldowns,
    playerCooldowns,
    playerBracing: false,
    canEscape: tpl.canEscape,
    round: 1,
    log: [`${tpl.name} engages you in combat!`]
  };

  gameState.combat = state;
  navigation.go("combat");
}

/**
 * Player action types.
 * For the UI, call playerCombatAction("fire", index) to fire a specific slot.
 */
export type PlayerCombatActionType = "fire" | "brace" | "flee";

/**
 * Main entry point for the player's turn.
 * - action: "fire" | "brace" | "flee"
 * - weaponIndex: required when action === "fire"
 */
export function playerCombatAction(
  action: PlayerCombatActionType,
  weaponIndex?: number
): void {
  const c = gameState.combat;
  if (!c) return;

  // Reset brace each turn; only applies to next enemy attack
  c.playerBracing = false;

  switch (action) {
    case "fire":
      if (weaponIndex === undefined) {
        log("You must choose a weapon to fire.");
        return;
      }
      playerFireWeapon(weaponIndex);
      break;

    case "brace":
      playerBrace();
      break;

    case "flee":
      if (attemptFlee()) {
        return; // escape successful, combat ended
      }
      break;
  }

  // Check if enemy died from player's action
  if (!gameState.combat) return; // might have ended
  if (c.enemyHp <= 0) {
    handleVictory();
    return;
  }

  // Enemy responds
  enemyTurn();

  // Check defeat
  if (!gameState.combat) return;
  if (gameState.ship.hp <= 0) {
    handleDefeat();
    return;
  }

  // End of round: tick cooldowns
  tickCooldowns();
  c.round += 1;
}

/**
 * Player fires a weapon from a given hardpoint slot.
 */
function playerFireWeapon(slotIndex: number) {
  const c = gameState.combat;
  if (!c) return;

  const weapons = gameState.ship.weapons || [];
  const weaponId = weapons[slotIndex] ?? null;
  const weapon = getWeaponDef(weaponId);

  if (!weapon) {
    log("That hardpoint has no weapon equipped.");
    return;
  }

  const cd = c.playerCooldowns[slotIndex] ?? 0;
  if (cd > 0) {
    log(`${weapon.name} is still recharging (${cd} turn(s) remaining).`);
    return;
  }

  // Build target state for damage calculation
  const targetState = {
    shields: c.enemyShields,
    hp: c.enemyHp
  };

  const dmg = computeWeaponDamage(weapon, targetState);
  if (dmg <= 0) {
    log(`You fire ${weapon.name}, but miss the ${c.enemyName}.`);
    // Set cooldown even on a miss
    c.playerCooldowns[slotIndex] = weapon.cooldown;
    return;
  }

  // Apply damage: shields first, then hull
  let remaining = dmg;
  if (c.enemyShields > 0) {
    const absorbed = Math.min(c.enemyShields, remaining);
    c.enemyShields -= absorbed;
    remaining -= absorbed;
  }
  if (remaining > 0) {
    c.enemyHp = Math.max(0, c.enemyHp - remaining);
  }

  log(`You hit the ${c.enemyName} with ${weapon.name} for ${dmg} damage.`);
  c.playerCooldowns[slotIndex] = weapon.cooldown;
}

/**
 * Player braces to reduce next incoming damage.
 */
function playerBrace() {
  const c = gameState.combat;
  if (!c) return;
  c.playerBracing = true;
  log("You divert power to maneuvering thrusters and brace for incoming fire.");
}

/**
 * Attempt to flee from combat.
 * Success chance can later factor in ship, roles, components, etc.
 */
function attemptFlee(): boolean {
  const c = gameState.combat;
  if (!c) return false;

  if (!c.canEscape) {
    log("The enemy has you locked down; you can't flee right now.");
    return false;
  }

  // Very simple base flee chance for now
  const baseChance = 0.5;
  const roll = Math.random();

  if (roll <= baseChance) {
    log("You break away from the engagement and jump clear.");
    gameState.combat = null;
    navigation.go("main");
    return true;
  } else {
    log("You attempt to flee, but the enemy pins you down.");
    return false;
  }
}

/**
 * Enemy's turn:
 * - Choose a ready weapon
 * - Fire at player
 */
function enemyTurn() {
  const c = gameState.combat;
  if (!c || !content) return;

  const enemyWeapons = c.enemyWeapons;
  const readyIndexes: number[] = [];

  enemyWeapons.forEach((id, idx) => {
    const cd = c.enemyCooldowns[idx] ?? 0;
    if (id && cd <= 0) {
      readyIndexes.push(idx);
    }
  });

  if (readyIndexes.length === 0) {
    log(`The ${c.enemyName} maneuvers, but its weapons are still cycling.`);
    return;
  }

  // Choose one ready weapon at random
  const idx = readyIndexes[randBetween(0, readyIndexes.length - 1)];
  const weaponId = enemyWeapons[idx];
  const weapon = getWeaponDef(weaponId);
  if (!weapon) {
    log(`The ${c.enemyName} fails to bring its weapons to bear.`);
    return;
  }

  // Target = player ship
  const ship = gameState.ship;
  const targetState = {
    shields: ship.shields,
    hp: ship.hp
  };

  let dmg = computeWeaponDamage(weapon, targetState);
  if (dmg <= 0) {
    log(`The ${c.enemyName} fires ${weapon.name}, but misses.`);
    c.enemyCooldowns[idx] = weapon.cooldown;
    return;
  }

  // Apply brace effect (reduce damage, e.g. 40%)
  if (c.playerBracing) {
    dmg = Math.round(dmg * 0.6);
  }

  // Apply to shields then hull
  let remaining = dmg;
  if (ship.shields > 0) {
    const absorbed = Math.min(ship.shields, remaining);
    ship.shields -= absorbed;
    remaining -= absorbed;
  }
  if (remaining > 0) {
    ship.hp = Math.max(0, ship.hp - remaining);
  }

  log(`The ${c.enemyName} hits you with ${weapon.name} for ${dmg} damage.`);
  c.enemyCooldowns[idx] = weapon.cooldown;
}

/**
 * Cooldown tick at end of each round.
 */
function tickCooldowns() {
  const c = gameState.combat;
  if (!c) return;

  c.playerCooldowns = c.playerCooldowns.map(cd => (cd > 0 ? cd - 1 : 0));
  c.enemyCooldowns = c.enemyCooldowns.map(cd => (cd > 0 ? cd - 1 : 0));
}

/**
 * Handle victory: grant basic reward, end combat.
 * You can later branch based on enemy type, contracts, etc.
 */
function handleVictory() {
  const c = gameState.combat;
  if (!c) return;

  log(`The ${c.enemyName} breaks apart under your fire. You are victorious.`);

  // Simple default reward; tune later.
  const rewardCredits = 200;
  gameState.player.credits += rewardCredits;
  log(`You salvage ${rewardCredits} credits from the wreckage.`);

  gameState.combat = null;
  navigation.go("main");
}

/**
 * Handle defeat: for now, cripple the ship and let player limp away.
 * You can later do game over, capture events, etc.
 */
function handleDefeat() {
  log("Your ship is crippled. Systems fail one by one as you drift in vacuum...");

  // Simple "barely survived" rule:
  gameState.ship.hp = 1;
  gameState.ship.shields = 0;

  // Optionally clear wanted or apply penalties here.
  gameState.combat = null;
  navigation.go("main");
}
