import { gameState } from "../core/state";
import { getCurrentShipTemplate, repairShip, refuelShip } from "../systems/shipSystem";
import { getInstalledComponents } from "../systems/componentSystem";

declare const nav: (screen: string) => void;

declare global {
  interface Window {
    repairShipAction: () => void;
    refuelShipAction: () => void;
  }
}

window.repairShipAction = () => {
  repairShip();
};

window.refuelShipAction = () => {
  refuelShip();
};

export function ShipScreen(): string {
  const ship = gameState.ship;
  const tpl = getCurrentShipTemplate();
  const comps = getInstalledComponents();

  const templateInfo = tpl
    ? `<p class="muted">${tpl.description}</p>`
    : `<p class="muted">Unknown template (${ship.templateId})</p>`;

  const componentsList =
    comps.length === 0
      ? `<p>No components installed.</p>`
      : `<ul>${comps
          .map((c) => `<li>${c.name} (+${c.value} ${c.effectType})</li>`)
          .join("")}</ul>`;

  return `
    <div class="screen ship">
      <h1>Ship: ${ship.name}</h1>
      ${templateInfo}

      <h2>Stats</h2>
      <p>Hull: ${ship.hp}/${ship.maxHp}</p>
      <p>Shields: ${ship.shields}/${ship.maxShields}</p>
      <p>Fuel: ${ship.fuel}/${ship.maxFuel}</p>
      <p>Cargo Capacity: ${ship.cargoCapacity}</p>

      <h2>Installed Components</h2>
      ${componentsList}

      <h2>Basic Services</h2>
      <ul class="actions">
        <li onclick="repairShipAction()">Repair to Full (1 cr per point)</li>
        <li onclick="refuelShipAction()">Refuel to Full (2 cr per fuel)</li>
        <li onclick="nav('main')">Back to Main</li>
      </ul>
    </div>
  `;
}
