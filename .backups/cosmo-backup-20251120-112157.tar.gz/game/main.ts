import { initGame } from "./core/engine";

document.addEventListener("DOMContentLoaded", () => {
  initGame();
});
