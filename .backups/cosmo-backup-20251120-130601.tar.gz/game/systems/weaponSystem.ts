import { gameState, persistLoadout } from "../core/state";
import { content, WeaponDef } from "../core/engine";
import { DAMAGE_TYPE_EFFECTS } from "./combatConstants";

/**
 * Get all available weapons (raw data).
 */
export function getAllWeapons(): WeaponDef[] {
  if (!content) return [];
  return content.weapons;
}

/**
 * Player's equipped weapons (by hardpoint index).
 */
export function getEquippedWeapons(): (WeaponDef | null)[] {
  if (!content) return [];
  const ship = gameState.ship;
  return ship.weapons.map((id) => content.weapons.find((w) => w.id === id) || null);
}

function ensureInventory() {
  if (!gameState.inventory) {
    gameState.inventory = { weapons: [] };
  }
  return gameState.inventory;
}

export function getInventoryWeaponIds(): string[] {
  const inventory = ensureInventory();
  return [...inventory.weapons];
}

export function autoEquipAvailableWeapons(): void {
  if (!content) return;
  const inv = getInventoryWeaponIds();
  if (!inv.length) return;

  const ship = gameState.ship;
  ship.weapons = ship.weapons.map((current, idx) => {
    if (current) return current; // already equipped
    const candidates = inv.filter((id) => canEquipWeapon(idx, id));
    if (!candidates.length) return current;
    const pick = candidates[Math.floor(Math.random() * candidates.length)];
    return pick;
  });
}

/**
 * Validate compatibility: size & type must match hardpoint.
 */
export function canEquipWeapon(hardpointIndex: number, weaponId: string): boolean {
  const ship = gameState.ship;
  const weapon = content?.weapons.find((w) => w.id === weaponId);
  if (!weapon) return false;

  const hardpoint = ship.hardpoints[hardpointIndex];
  if (!hardpoint) return false;

  return weapon.size === hardpoint.size && weapon.type === hardpoint.type;
}

/**
 * Equip weapon into a slot.
 */
export function equipWeapon(hardpointIndex: number, weaponId: string): boolean {
  if (!canEquipWeapon(hardpointIndex, weaponId)) return false;

  gameState.ship.weapons[hardpointIndex] = weaponId;
  persistLoadout();
  return true;
}

export function getWeaponById(weaponId: string | null): WeaponDef | null {
  if (!weaponId || !content) return null;
  return content.weapons.find((w) => w.id === weaponId) ?? null;
}

export function buyWeapon(weaponId: string): boolean {
  const weapon = getWeaponById(weaponId);
  if (!weapon) return false;
  if (gameState.player.credits < weapon.price) return false;
  const inventory = ensureInventory();
  inventory.weapons.push(weaponId);
  gameState.player.credits -= weapon.price;
  persistLoadout();
  return true;
}
/**
 * Damage calculation for combat.
 */
export interface DamageOptions {
  accuracyMultiplier?: number;
  damageMultiplier?: number;
}

/**
 * Damage calculation for combat, with optional modifiers for aim modes and stance.
 */
export function computeWeaponDamage(
  weapon: WeaponDef,
  enemyState: { shields: number; hp: number },
  opts: DamageOptions = {}
): number {
  let dmg = weapon.damage;
  const typeEffect = DAMAGE_TYPE_EFFECTS[weapon.damageType];

  // conditional shield/hull mods + damage-type multiplier
  if (enemyState.shields > 0) {
    dmg *= weapon.shieldMod * (typeEffect?.shield ?? 1);
  } else {
    dmg *= weapon.armorMod * (typeEffect?.hull ?? 1);
  }

  // weapon role modifiers
  const tags = weapon.tags || [];
  if (enemyState.shields > 0 && tags.includes("shield_breaker")) {
    dmg *= 1.2;
  }
  if (enemyState.shields <= 0 && tags.includes("armor_piercing")) {
    dmg *= 1.2;
  }

  // accuracy roll (apply aim modifiers + accurate tag)
  let accuracy = weapon.accuracy * (opts.accuracyMultiplier ?? 1);
  if (tags.includes("accurate")) {
    accuracy += 0.05;
  }
  accuracy = Math.min(0.95, Math.max(0, accuracy));
  if (Math.random() > accuracy) return 0;

  // critical hit
  if (Math.random() < weapon.critChance) dmg *= weapon.critMultiplier;

  // aim/stance damage modifiers
  dmg *= opts.damageMultiplier ?? 1;

  return Math.round(dmg);
}
