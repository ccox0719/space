import { getBuyableShips, buyShip } from "../systems/shipSystem";
import { getAllComponents, buyAndInstallComponent } from "../systems/componentSystem";
import {
  getAllWeapons,
  buyWeapon,
  getInventoryWeaponIds,
  getWeaponById
} from "../systems/weaponSystem";
import { gameState } from "../core/state";
import { systemHasTag } from "../systems/systemHelpers";

declare global {
  interface Window {
    buyShipAction: (id: string) => void;
    buyComponentAction: (id: string) => void;
    buyWeaponAction: (id: string) => void;
  }
}

window.buyShipAction = (id: string) => {
  buyShip(id);
};

window.buyComponentAction = (id: string) => {
  buyAndInstallComponent(id);
};

window.buyWeaponAction = (id: string) => {
  buyWeapon(id);
};

declare const nav: (screen: string) => void;

export function ShipyardScreen(): string {
  if (!systemHasTag(gameState.location.systemId, "shipyard")) {
    return `
      <div class="screen shipyard">
        <h1>No Shipyard Here</h1>
        <p>This system does not have certified shipyard facilities.</p>
        <ul class="actions">
          <li onclick="nav('main')">Back</li>
        </ul>
      </div>
    `;
  }

  const ships = getBuyableShips();
  const comps = getAllComponents();
  const weapons = getAllWeapons();
  const inventoryNames = getInventoryWeaponIds()
    .map((id) => getWeaponById(id)?.name)
    .filter(Boolean);

  const shipsHtml =
    ships.length === 0
      ? `<p>No ships are currently for sale.</p>`
      : ships
          .map(
            (s) => `
        <div class="card">
          <h3>${s.name}</h3>
          <p class="muted">${s.description}</p>
          <p>Role: ${s.roleHint}</p>
          <p>Hull: ${s.hull} | Shields: ${s.shields}</p>
          <p>Fuel: ${s.fuel} | Cargo: ${s.cargo}</p>
          <p><strong>Cost:</strong> ${s.cost} cr</p>
          <button onclick="buyShipAction('${s.id}')">Buy & Replace Current Ship</button>
        </div>
      `
          )
          .join("");

  const compsHtml =
    comps.length === 0
      ? `<p>No components in stock.</p>`
      : comps
          .map(
            (c) => `
        <div class="card">
          <h3>${c.name}</h3>
          <p class="muted">${c.description}</p>
          <p><strong>Effect:</strong> +${c.value} ${c.effectType}</p>
          <p><strong>Cost:</strong> ${c.cost} cr</p>
          <button onclick="buyComponentAction('${c.id}')">Buy & Install</button>
        </div>
      `
          )
          .join("");

  const weaponsHtml =
    weapons.length === 0
      ? `<p>No weapons available.</p>`
      : weapons
          .map(
            (w) => `
        <div class="card">
          <h3>${w.name}</h3>
          <p>${w.type} / ${w.size}</p>
          <p>Damage: ${w.damage} (${w.damageType})</p>
          <p>Accuracy: ${Math.round(w.accuracy * 100)}%</p>
          <p>Crit: ${Math.round(w.critChance * 100)}% ×${w.critMultiplier}</p>
          <p>Cooldown: ${w.cooldown} | Energy: ${w.energyCost}</p>
          <p>Tags: ${w.tags.join(", ")}</p>
          <p><strong>Price:</strong> ${w.price} cr</p>
          <button onclick="buyWeaponAction('${w.id}')">Buy Weapon</button>
        </div>
      `
          )
          .join("");

  const inventoryHtml =
    inventoryNames.length > 0
      ? `<p>${inventoryNames.join(", ")}</p>`
      : "<p>You currently own no weapons.</p>";

  return `
    <div class="screen shipyard">
      <h1>Shipyard</h1>
      <p>Credits: ${gameState.player.credits}</p>

      <h2>Ships for Sale</h2>
      ${shipsHtml}

      <h2>Components & Upgrades</h2>
      ${compsHtml}

      <h2>Weapons for Sale</h2>
      ${weaponsHtml}

      <h2>Your Weapon Inventory</h2>
      ${inventoryHtml}

      <ul class="actions">
        <li onclick="nav('main')">Back to Main</li>
      </ul>
    </div>
  `;
}
