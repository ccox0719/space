import { getStarterShips, chooseStarterShip } from "../systems/shipSystem";
import { autoEquipAvailableWeapons } from "../systems/weaponSystem";
import { navigation } from "../core/navigation";

declare global {
  interface Window {
    chooseStarter: (id: string) => void;
  }
}

window.chooseStarter = (id: string) => {
  chooseStarterShip(id);
  // Immediately fill empty hardpoints from owned weapons so the player isn't unarmed.
  autoEquipAvailableWeapons();
  navigation.go("main");
};

declare const nav: (screen: string) => void;

export function ShipSelectScreen(): string {
  const starters = getStarterShips();

  if (starters.length === 0) {
    return `
      <div class="screen ship-select">
        <h1>Select Your Starter Ship</h1>
        <p>No starter ships defined. Please add some in ships.json.</p>
        <ul class="actions">
          <li onclick="nav('main')">Continue</li>
        </ul>
      </div>
    `;
  }

  const list = starters
    .map(
      (s) => `
      <div class="card">
        <h2>${s.name}</h2>
        <p class="muted">${s.description}</p>
        <p><strong>Role hint:</strong> ${s.roleHint}</p>
        <p>Hull: ${s.hull} | Shields: ${s.shields}</p>
        <p>Fuel: ${s.fuel} | Cargo: ${s.cargo}</p>
        <button onclick="chooseStarter('${s.id}')">Choose ${s.name}</button>
      </div>
    `
    )
    .join("");

  return `
    <div class="screen ship-select">
      <h1>Select Your Starter Ship</h1>
      <p>Choose the hull that will define your early game playstyle.</p>
      ${list}
    </div>
  `;
}
