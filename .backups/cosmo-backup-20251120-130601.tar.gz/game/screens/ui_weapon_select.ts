import { gameState } from "../core/state";
import {
  canEquipWeapon,
  equipWeapon,
  getWeaponById,
  getInventoryWeaponIds
} from "../systems/weaponSystem";

declare const nav: (screen: string, params?: Record<string, unknown>) => void;

declare global {
  interface Window {
    equipWeaponAction: (slotIndex: number, weaponId: string) => void;
  }
}

window.equipWeaponAction = (slotIndex: number, weaponId: string) => {
  if (equipWeapon(slotIndex, weaponId)) {
    nav("weapon_slots");
  }
};

export function WeaponSelectScreen(params: Record<string, unknown> = {}): string {
  const slotIndex =
    typeof params.slotIndex === "number" && params.slotIndex >= 0
      ? params.slotIndex
      : 0;
  const slot = gameState.ship.hardpoints[slotIndex];
  if (!slot) {
    return `
      <div class="screen weapon-select">
        <h1>Weapon Selection</h1>
        <p>Invalid hardpoint.</p>
        <ul class="actions">
          <li onclick="nav('weapon_slots')">Back to Hardpoints</li>
        </ul>
      </div>
    `;
  }

  const ownedWeaponIds = getInventoryWeaponIds();
  const ownedWeapons = ownedWeaponIds
    .map((id) => getWeaponById(id))
    .filter((w): w is NonNullable<ReturnType<typeof getWeaponById>> => !!w);

  const rows = ownedWeapons
    .map((weapon) => {
      const compatible = canEquipWeapon(slotIndex, weapon.id);
      const equipped = getWeaponById(gameState.ship.weapons[slotIndex])?.id === weapon.id;
      const buttonLabel = equipped ? "Equipped" : "Equip";
      return `
        <tr class="${compatible ? "" : "muted"}">
          <td>${weapon.name}</td>
          <td>${weapon.damage} dmg</td>
          <td>Acc: ${Math.round(weapon.accuracy * 100)}%</td>
          <td>Crit: ${Math.round(weapon.critChance * 100)}% (×${weapon.critMultiplier})</td>
          <td>CD: ${weapon.cooldown}</td>
          <td>Size: ${weapon.size} / ${weapon.type}</td>
          <td>
            <button ${compatible ? "" : "disabled"} onclick="equipWeaponAction(${slotIndex}, '${weapon.id}')">
              ${buttonLabel}
            </button>
          </td>
        </tr>
      `;
    })
    .join("");

  const tableBody =
    rows ||
    `<tr><td colspan="7">No owned weapons available. Buy or loot weapons to equip.</td></tr>`;

  return `
    <div class="screen weapon-select">
      <h1>Weapon Selection</h1>
      <p>Hardpoint: ${slot.size} ${slot.type}</p>
      <table>
        <thead>
          <tr><th>Weapon</th><th>Damage</th><th>Accuracy</th><th>Crit</th><th>Cooldown</th><th>Type</th><th>Action</th></tr>
        </thead>
        <tbody>
          ${tableBody}
        </tbody>
      </table>
      <ul class="actions">
        <li onclick="nav('weapon_slots')">Back to Hardpoints</li>
      </ul>
    </div>
  `;
}
