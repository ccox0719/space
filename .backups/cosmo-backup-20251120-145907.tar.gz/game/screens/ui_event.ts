import { getEventById, applyConsequence } from "../systems/eventSystem";
import { navigation } from "../core/navigation";
import { startCombat } from "../systems/combatSystem";
import { startMiningSession } from "../systems/miningSystem";
import { gameState } from "../core/state";

declare const nav: (screen: string, params?: Record<string, unknown>) => void;
declare const pickChoice: (choiceIdx: number) => void;
declare const beginMiningSession: (beltId?: string, resourceId?: string) => void;

export function EventScreen(params: Record<string, unknown> = {}): string {
  const eventId = typeof params.eventId === "string" ? params.eventId : "";
  const ev = getEventById(eventId);

  if (!ev) {
    return `
      <div class="screen event">
        <h1>No Event</h1>
        <p>No events available here.</p>
        <ul class="actions">
          <li onclick="nav('main')">Back to Main</li>
        </ul>
      </div>
    `;
  }

  if (ev.type === "mining") {
    return `
      <div class="screen event">
        <h1>${ev.name}</h1>
        ${ev.description ? `<p>${ev.description}</p>` : ""}
        <p>Secure your mining rig and hope the pirates stay away.</p>
        <ul class="actions">
          <li onclick="beginMiningSession(${JSON.stringify(ev.beltId ?? "")}, ${JSON.stringify(ev.miningCommodityId ?? "")})">
            Enter Mining Belt
          </li>
          <li onclick="nav('main')">Decline</li>
        </ul>
      </div>
    `;
  }

  const choices = (ev.choices || [])
    .map((choice, idx) => {
      const riskText = choice.risk
        ? `<small>Risk: ${Math.round(
            (choice.risk.dangerChance ?? 0) * 100
          )}%</small>`
        : "";
      return `
        <li onclick="pickChoice(${idx})">
          <strong>${choice.label}</strong>
          ${choice.description ? `<p>${choice.description}</p>` : ""}
          ${riskText}
        </li>
      `;
    })
    .join("");

  const choiceBlock = choices
    ? `<ul class="actions">${choices}</ul>`
    : `<p>No choices; this event resolves on its own.</p>`;

  return `
    <div class="screen event">
      <h1>${ev.name}</h1>
      ${ev.description ? `<p>${ev.description}</p>` : ""}
      <p><em>Type: ${ev.type}</em></p>
      <h3>Choices</h3>
      ${choiceBlock}
      <ul class="actions">
        <li onclick="nav('main')">Back to Main</li>
      </ul>
    </div>
  `;
}

declare global {
  interface Window {
    pickChoice: (choiceIdx: number) => void;
    beginMiningSession: (beltId?: string, resourceId?: string) => void;
  }
}

window.pickChoice = (choiceIdx: number) => {
  const params = navigation.params;
  const eventId = typeof params.eventId === "string" ? params.eventId : "";
  const ev = getEventById(eventId);
  if (!ev) {
    nav("main");
    return;
  }
  const choice = ev.choices?.[choiceIdx];
  if (choice) {
    const resolution = applyConsequence(choice);
    if (resolution.triggerCombat?.enemyId) {
      startCombat(resolution.triggerCombat.enemyId);
      return;
    }
  }
  nav("main", { message: `Outcome: ${choice?.label || ev.name}` });
};

window.beginMiningSession = (beltId?: string, resourceId?: string) => {
  startMiningSession(
    gameState,
    gameState.location.systemId,
    beltId || undefined,
    resourceId || undefined
  );
  navigation.go("mining");
};
