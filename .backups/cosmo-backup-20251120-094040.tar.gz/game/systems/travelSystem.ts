import { gameState } from "../core/engine";
import { navigation } from "../core/navigation";
import { pickEvent, getEventById } from "./eventSystem";
import { recordTravel, consumeMissionEventId, tickMissionTimers } from "./missionSystem";

export interface StarSystem {
  id: string;
  name: string;
  description: string;
  security: string;
  faction: string;
  tags: string[];
  neighbors: string[];
  marketModifiers?: Record<string, number>;
  eventWeights?: Record<string, number>;
}

let systems: StarSystem[] = [];

export function setSystems(data: StarSystem[]): void {
  systems = data;
}

export function getSystemById(id: string): StarSystem | undefined {
  return systems.find((s) => s.id === id);
}

export function getNeighbors(systemId: string): StarSystem[] {
  const node = getSystemById(systemId);
  if (!node) return [];
  return node.neighbors
    .map((id) => getSystemById(id))
    .filter((s): s is StarSystem => Boolean(s));
}

export function travelTo(targetSystemId: string): void {
  const target = getSystemById(targetSystemId);
  if (!target) return;

  const fuelCost = 1;
  if (gameState.ship.fuel < fuelCost) {
    navigation.go("travel", { error: "Not enough fuel to jump." });
    return;
  }

  gameState.ship.fuel -= fuelCost;
  gameState.location.systemId = target.id;
  gameState.location.docked = true;
  gameState.time.turn += 1;
  recordTravel(target.id);
  tickMissionTimers();
  const forcedEventId = consumeMissionEventId();
  if (forcedEventId) {
    const forced = getEventById(forcedEventId);
    if (forced) {
      navigation.go("event", { eventId: forced.id });
      return;
    }
  }

  const ev = pickEvent(target);
  if (ev) {
    navigation.go("event", { eventId: ev.id });
  } else {
    navigation.go("main", { message: `Arrived at ${target.name}.` });
  }
}
