import { navigation } from "./navigation";
import { MainScreen } from "../screens/ui_main";
import { TravelScreen } from "../screens/ui_travel";
import { MarketScreen } from "../screens/ui_market";
import { ContractsScreen } from "../screens/ui_contracts";
import { ShipScreen } from "../screens/ui_ship";
import { CrewScreen } from "../screens/ui_crew";
import { EventScreen } from "../screens/ui_event";
import { CombatScreen } from "../screens/ui_combat";

export function render() {
  const app = document.getElementById("app");
  if (!app) return;

  let html = "";

  switch (navigation.current) {
    case "main":
      html = MainScreen();
      break;
    case "travel":
      html = TravelScreen();
      break;
    case "market":
      html = MarketScreen();
      break;
    case "contracts":
      html = ContractsScreen();
      break;
    case "ship":
      html = ShipScreen();
      break;
    case "crew":
      html = CrewScreen();
      break;
    case "event":
      html = EventScreen(navigation.params);
      break;
    case "combat":
      html = CombatScreen(navigation.params);
      break;
  }

  app.innerHTML = html;
}
