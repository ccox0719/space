import { gameState } from "../core/engine";
import { playerCombatAction } from "../systems/combatSystem";

declare const nav: (screen: string, params?: Record<string, unknown>) => void;

declare global {
  interface Window {
    combatAction: (action: string) => void;
  }
}

window.combatAction = (action: string) => {
  if (
    action === "attack" ||
    action === "brace" ||
    action === "target_engines" ||
    action === "flee"
  ) {
    playerCombatAction(action);
    if (gameState.combat) {
      nav("combat");
    }
  }
};

export function CombatScreen(): string {
  const c = gameState.combat;

  if (!c) {
    return `
      <div class="screen combat">
        <h1>No Active Combat</h1>
        <p>You are not currently engaged in combat.</p>
        <ul class="actions">
          <li onclick="nav('main')">Back to Main</li>
        </ul>
      </div>
    `;
  }

  const ship = gameState.ship;
  const logHtml = c.log.map((line) => `<div class="log-line">${line}</div>`).join("");

  return `
    <div class="screen combat">
      <h1>Combat: ${c.enemyName}</h1>

      <div class="combat-status">
        <h2>Your Ship</h2>
        <p>HP: ${ship.hp}/${ship.maxHp}</p>
        <p>Shields: ${ship.shields}/${ship.maxShields}</p>
        <p>Fuel: ${ship.fuel}/${ship.maxFuel}</p>
      </div>

      <div class="combat-status">
        <h2>Enemy</h2>
        <p>HP: ${c.enemyHp}/${c.enemyMaxHp}</p>
        <p>Shields: ${c.enemyShields}/${c.enemyMaxShields}</p>
      </div>

      <h2>Actions</h2>
      <ul class="actions">
        <li onclick="combatAction('attack')">Attack</li>
        <li onclick="combatAction('brace')">Brace</li>
        <li onclick="combatAction('target_engines')">Target Engines</li>
        <li onclick="combatAction('flee')">Attempt Flee</li>
        <li onclick="nav('main')">Retreat to Main (debug)</li>
      </ul>

      <h2>Battle Log</h2>
      <div class="combat-log">
        ${logHtml}
      </div>
    </div>
  `;
}
