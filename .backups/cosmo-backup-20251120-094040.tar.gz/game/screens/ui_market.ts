import { gameState } from "../core/engine";
import { getSystemById } from "../systems/travelSystem";
import { getMarketQuotes, buy, sell, buyFuel } from "../systems/economySystem";
import { recordDelivery } from "../systems/missionSystem";

declare const nav: (screen: string, params?: Record<string, unknown>) => void;
declare const trade: (action: "buy" | "sell", commodityId: string) => void;

export function MarketScreen(): string {
  const system = getSystemById(gameState.location.systemId);
  const quotes = getMarketQuotes(system);
  const cargoLoad = getCargoLoad();

  const rows =
    quotes
      .map(
        (q) => {
          const isFuel = q.commodity.id === "fuel";
          const held = isFuel
            ? `${gameState.ship.fuel}/${gameState.ship.maxFuel}`
            : gameState.ship.cargo[q.commodity.id] || 0;

          const actions = isFuel
            ? `<button onclick="trade('buy','${q.commodity.id}')">Buy Fuel (+1)</button>`
            : `
                <button onclick="trade('buy','${q.commodity.id}')">Buy</button>
                <button onclick="trade('sell','${q.commodity.id}')">Sell</button>
              `;

          return `
            <tr>
              <td>${q.commodity.name}</td>
              <td>${q.price} cr</td>
              <td>${held}</td>
              <td>${actions}</td>
            </tr>
          `;
        }
      )
      .join("") || "<tr><td colspan=\"4\">No market data</td></tr>";

  return `
    <div class="screen market">
      <h1>Market — ${system?.name || "Unknown"}</h1>
      <p>Credits: ${gameState.player.credits} | Cargo: ${cargoLoad}/${gameState.ship.cargoCapacity}</p>
      <table>
        <thead>
          <tr><th>Commodity</th><th>Price</th><th>Held</th><th>Actions</th></tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>
      <p id="market-message"></p>
      <ul class="actions">
        <li onclick="nav('main')">Back to Main</li>
      </ul>
    </div>
  `;
}

function getCargoLoad(): number {
  return Object.values(gameState.ship.cargo).reduce((sum, qty) => sum + qty, 0);
}

declare global {
  interface Window {
    trade: (action: "buy" | "sell", commodityId: string) => void;
  }
}

window.trade = (action: "buy" | "sell", commodityId: string) => {
  const system = getSystemById(gameState.location.systemId);
  const quote = getMarketQuotes(system).find((q) => q.commodity.id === commodityId);
  if (!quote) return;

  const quantity = 1; // simple placeholder qty
  const result =
    action === "buy"
      ? commodityId === "fuel"
        ? buyFuel(quantity, quote.price)
        : buy(commodityId, quantity, quote.price)
      : sell(commodityId, quantity, quote.price);

  if (result.success && action === "sell" && system) {
    recordDelivery(commodityId, quantity, system.id);
  }
  if (result.success && system) {
    logTrade(action, commodityId, quantity, quote.price, system.id);
  }
  const msgEl = document.getElementById("market-message");
  if (msgEl) {
    msgEl.textContent = result.success
      ? `${action === "buy" ? "Bought" : "Sold"} ${quantity} ${quote.commodity.name}`
      : result.reason || "Action failed";
  }

  nav("market"); // rerender to reflect state
};

function logTrade(
  action: "buy" | "sell",
  commodityId: string,
  quantity: number,
  price: number,
  systemId: string
): void {
  gameState.transactions.push({
    action,
    commodityId,
    quantity,
    price,
    systemId,
    turn: gameState.time.turn
  });
  if (gameState.transactions.length > 10) {
    gameState.transactions = gameState.transactions.slice(-10);
  }
}
