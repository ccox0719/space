export type ScreenID =
  | "main"
  | "travel"
  | "market"
  | "contracts"
  | "ship"
  | "crew"
  | "event"
  | "combat"
  | "shipyard"
  | "ship_select";

interface NavigationState {
  current: ScreenID;
  params: Record<string, unknown>;
}

export const navigation: NavigationState & {
  go: (screen: ScreenID, params?: Record<string, unknown>) => void;
} = {
  current: "main",
  params: {},
  go(screen: ScreenID, params: Record<string, unknown> = {}) {
    this.current = screen;
    this.params = params;
    // renderer.render() will be wired in engine.ts
  }
};
