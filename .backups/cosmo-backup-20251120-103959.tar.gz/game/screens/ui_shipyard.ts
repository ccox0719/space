import { getBuyableShips, buyShip } from "../systems/shipSystem";
import { getAllComponents, buyAndInstallComponent } from "../systems/componentSystem";
import { gameState } from "../core/state";
import { systemHasTag } from "../systems/systemHelpers";

declare global {
  interface Window {
    buyShipAction: (id: string) => void;
    buyComponentAction: (id: string) => void;
  }
}

window.buyShipAction = (id: string) => {
  buyShip(id);
};

window.buyComponentAction = (id: string) => {
  buyAndInstallComponent(id);
};

declare const nav: (screen: string) => void;

export function ShipyardScreen(): string {
  if (!systemHasTag(gameState.location.systemId, "shipyard")) {
    return `
      <div class="screen shipyard">
        <h1>No Shipyard Here</h1>
        <p>This system does not have certified shipyard facilities.</p>
        <ul class="actions">
          <li onclick="nav('main')">Back</li>
        </ul>
      </div>
    `;
  }

  const ships = getBuyableShips();
  const comps = getAllComponents();

  const shipsHtml =
    ships.length === 0
      ? `<p>No ships are currently for sale.</p>`
      : ships
          .map(
            (s) => `
        <div class="card">
          <h3>${s.name}</h3>
          <p class="muted">${s.description}</p>
          <p>Role: ${s.roleHint}</p>
          <p>Hull: ${s.hull} | Shields: ${s.shields}</p>
          <p>Fuel: ${s.fuel} | Cargo: ${s.cargo}</p>
          <p><strong>Cost:</strong> ${s.cost} cr</p>
          <button onclick="buyShipAction('${s.id}')">Buy & Replace Current Ship</button>
        </div>
      `
          )
          .join("");

  const compsHtml =
    comps.length === 0
      ? `<p>No components in stock.</p>`
      : comps
          .map(
            (c) => `
        <div class="card">
          <h3>${c.name}</h3>
          <p class="muted">${c.description}</p>
          <p><strong>Effect:</strong> +${c.value} ${c.effectType}</p>
          <p><strong>Cost:</strong> ${c.cost} cr</p>
          <button onclick="buyComponentAction('${c.id}')">Buy & Install</button>
        </div>
      `
          )
          .join("");

  return `
    <div class="screen shipyard">
      <h1>Shipyard</h1>
      <p>Credits: ${gameState.player.credits}</p>

      <h2>Ships for Sale</h2>
      ${shipsHtml}

      <h2>Components & Upgrades</h2>
      ${compsHtml}

      <ul class="actions">
        <li onclick="nav('main')">Back to Main</li>
      </ul>
    </div>
  `;
}
