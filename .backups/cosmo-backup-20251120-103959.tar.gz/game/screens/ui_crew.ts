import { gameState } from "../core/state";

declare const nav: (screen: string, params?: Record<string, unknown>) => void;
declare const assignCrewRole: (crewId: string, role: string) => void;

export function CrewScreen(): string {
  const crew = gameState.crew;

  const crewList =
    crew.length > 0
      ? crew
          .map(
            (member) => `
              <li>
                <strong>${member.name}</strong> — ${member.role} (Tier ${member.tier})
                <div>Morale: ${(member.morale * 100).toFixed(0)}%</div>
                <div>
                  <label>
                    Assign role:
                    <input type="text" id="role-${member.id}" value="${member.role}" />
                  </label>
                  <button onclick="assignCrewRole('${member.id}', document.getElementById('role-${member.id}').value)">Update</button>
                </div>
              </li>
            `
          )
          .join("")
      : "<p>No crew aboard.</p>";

  return `
    <div class="screen crew">
      <h1>Crew</h1>
      <ul class="actions">
        ${crewList}
      </ul>
      <ul class="actions">
        <li onclick="nav('main')">Back to Main</li>
      </ul>
    </div>
  `;
}

declare global {
  interface Window {
    assignCrewRole: (crewId: string, role: string) => void;
  }
}

window.assignCrewRole = (crewId: string, role: string) => {
  const member = gameState.crew.find((c) => c.id === crewId);
  if (!member) return;
  member.role = role;
  nav("crew");
};
