import { gameState, ShipState } from "../core/state";
import { content, ShipDef } from "../core/engine";

/**
 * Look up a ship template from content by id.
 */
export function getShipTemplate(id: string): ShipDef | null {
  if (!content) return null;
  return content.ships.find((s) => s.id === id) ?? null;
}

/**
 * Get the template for the player's current ship.
 */
export function getCurrentShipTemplate(): ShipDef | null {
  return getShipTemplate(gameState.ship.templateId);
}

/**
 * Get all starter ship templates (for the initial selection).
 */
export function getStarterShips(): ShipDef[] {
  if (!content) return [];
  return content.ships.filter((s) => s.starter);
}

/**
 * Get all non-starter ships available to buy.
 */
export function getBuyableShips(): ShipDef[] {
  if (!content) return [];
  return content.ships.filter((s) => !s.starter);
}

/**
 * Replace the player's ship with a new template.
 * For starter selection and ship purchases.
 */
export function applyShipTemplate(templateId: string, customName?: string) {
  const tpl = getShipTemplate(templateId);
  if (!tpl) {
    console.warn(`Unknown ship template: ${templateId}`);
    return;
  }

  const newShip: ShipState = {
    templateId: tpl.id,
    name: customName || tpl.name,
    hp: tpl.hull,
    maxHp: tpl.hull,
    shields: tpl.shields,
    maxShields: tpl.shields,
    fuel: tpl.fuel,
    maxFuel: tpl.fuel,
    cargoCapacity: tpl.cargo,
    components: []
  };

  gameState.ship = newShip;
}

/**
 * Choose a starter ship at the beginning of the game.
 */
export function chooseStarterShip(templateId: string) {
  applyShipTemplate(templateId);
  gameState.player.hasChosenStarter = true;
}

/**
 * Attempt to buy a new ship (replacing the current one).
 * For now this simply overwrites your ship.
 */
export function buyShip(templateId: string): boolean {
  const tpl = getShipTemplate(templateId);
  if (!tpl) {
    console.warn(`Unknown ship template: ${templateId}`);
    return false;
  }

  if (tpl.starter) {
    console.warn("Starter ships are not sold at shipyards.");
    return false;
  }

  if (gameState.player.credits < tpl.cost) {
    console.warn("Not enough credits to buy this ship.");
    return false;
  }

  gameState.player.credits -= tpl.cost;
  applyShipTemplate(templateId);
  return true;
}

/**
 * Simple repair: restore hull and shields to max for a flat credit cost.
 */
export function repairShip(): void {
  const ship = gameState.ship;
  const missingHull = ship.maxHp - ship.hp;
  const missingShields = ship.maxShields - ship.shields;

  if (missingHull <= 0 && missingShields <= 0) {
    return;
  }

  // Very simple formula: 1 credit per point for now
  const cost = missingHull + missingShields;

  if (gameState.player.credits < cost) {
    console.warn("Not enough credits to fully repair.");
    return;
  }

  gameState.player.credits -= cost;
  ship.hp = ship.maxHp;
  ship.shields = ship.maxShields;
}

/**
 * Simple refuel: top up to max for cost.
 */
export function refuelShip(): void {
  const ship = gameState.ship;
  const missingFuel = ship.maxFuel - ship.fuel;
  if (missingFuel <= 0) {
    return;
  }

  // Example: 2 credits per fuel for now
  const costPerUnit = 2;
  const cost = missingFuel * costPerUnit;

  if (gameState.player.credits < cost) {
    console.warn("Not enough credits to fully refuel.");
    return;
  }

  gameState.player.credits -= cost;
  ship.fuel = ship.maxFuel;
}
