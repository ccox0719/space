import { gameState } from "../core/state";
import { SystemDef } from "../core/engine";
import { acceptMission, tickMissionTimers, getActiveContracts } from "./missionSystem";

export interface EventChoice {
  text: string;
  consequence?: {
    creditsDelta?: number;
    fuelDelta?: number;
    cargoGain?: Record<string, number>;
    cargoLoss?: Record<string, number>;
    turnDelta?: number;
    spawnMissionId?: string;
  };
}

export interface GameEvent {
  id: string;
  title: string;
  description: string;
  weight: number;
  tags: string[];
  choices: EventChoice[];
}

export interface EventContext {
  context: "travel" | string;
  from?: SystemDef;
  to?: SystemDef;
  hazardChance?: number;
  routeType?: string;
  travelTime?: number;
}

const TRAVEL_EVENT_IDS = [
  "pirate_ambush",
  "navy_inspection",
  "smuggler_contact",
  "anomaly_scan"
];

function computeTravelEventWeights(context: EventContext): Record<string, number> {
  const weights: Record<string, number> = {
    pirate_ambush: 1,
    navy_inspection: 0.8,
    smuggler_contact: 0.4,
    anomaly_scan: 0.3
  };

  const to = context.to;
  const from = context.from;

  if (to?.security === "high") {
    weights.pirate_ambush -= 0.5;
    weights.navy_inspection += 0.6;
    weights.anomaly_scan -= 0.2;
  } else if (to?.security === "low") {
    weights.pirate_ambush += 0.4;
    weights.navy_inspection -= 0.3;
    weights.anomaly_scan += 0.2;
  } else {
    weights.pirate_ambush += 0.1;
    weights.navy_inspection += 0.1;
  }

  const tags = new Set<string>();
  (to?.tags || []).forEach((tag) => tags.add(tag));
  (from?.tags || []).forEach((tag) => tags.add(tag));

  if (tags.has("frontier") || tags.has("mining_belt")) {
    weights.pirate_ambush += 0.3;
    weights.anomaly_scan += 0.25;
  }
  if (tags.has("anomaly")) {
    weights.anomaly_scan += 0.3;
  }

  if (context.routeType === "wild_jump") {
    weights.pirate_ambush += 0.2;
    weights.anomaly_scan += 0.15;
  }
  if (context.routeType === "trade_lane") {
    weights.navy_inspection += 0.25;
    weights.pirate_ambush -= 0.2;
  }

  if (tags.has("checkpoint")) {
    weights.navy_inspection += 0.35;
    weights.pirate_ambush -= 0.2;
  }
  if (tags.has("trade_lane")) {
    weights.navy_inspection += 0.2;
  }
  if (tags.has("restricted")) {
    weights.navy_inspection += 0.3;
    if (gameState.player.wanted >= 50) {
      weights.pirate_ambush += 0.2;
    }
  }

  const wantedFactor = Math.min(1, gameState.player.wanted / 100);
  weights.pirate_ambush += wantedFactor * 0.5;
  if (gameState.player.wanted >= 75) {
    weights.navy_inspection += 0.2;
  }

  const travelContracts = getActiveContracts().filter(
    (c) => (c.requirements as { travel?: { systemId?: string } } | undefined)?.travel?.systemId === to?.id
  );
  if (travelContracts.length) {
    weights.smuggler_contact += 0.2 * travelContracts.length;
    weights.anomaly_scan += 0.1;
  }

  const normalized: Record<string, number> = {};
  for (const id of TRAVEL_EVENT_IDS) {
    normalized[id] = Math.max(0, weights[id] ?? 0);
  }
  return normalized;
}

let events: GameEvent[] = [];

export function setEvents(data: GameEvent[]): void {
  events = data;
}

export function getEvents(): GameEvent[] {
  return events;
}

export function getEventById(id: string): GameEvent | undefined {
  return events.find((e) => e.id === id);
}

export function pickEvent(context: EventContext): GameEvent | undefined {
  if (context.context !== "travel" || !context.to) return undefined;

  const hazard = Math.max(0, Math.min(1, context.hazardChance ?? 0.4));
  if (Math.random() > hazard) {
    return undefined;
  }

  const weights = computeTravelEventWeights(context);
  const entries = Object.entries(weights).filter(([, w]) => w > 0);
  if (!entries.length) return undefined;

  const total = entries.reduce((sum, [, weight]) => sum + weight, 0);
  let roll = Math.random() * total;
  for (const [eventId, weight] of entries) {
    roll -= weight;
    if (roll <= 0) {
      return getEventById(eventId);
    }
  }

  return getEventById(entries[0][0]);
}

export function applyConsequence(choice: EventChoice): void {
  const c = choice.consequence;
  if (!c) return;

  if (typeof c.creditsDelta === "number") {
    gameState.player.credits += c.creditsDelta;
    if (gameState.player.credits < 0) gameState.player.credits = 0;
  }

  if (typeof c.fuelDelta === "number") {
    const capacity = gameState.ship.maxFuel;
    gameState.ship.fuel = Math.max(
      0,
      Math.min(capacity, gameState.ship.fuel + c.fuelDelta)
    );
  }

  if (typeof c.turnDelta === "number") {
    gameState.time.turn += c.turnDelta;
    tickMissionTimers();
  }

  if (c.cargoGain) {
    for (const [id, qty] of Object.entries(c.cargoGain)) {
      gameState.ship.cargo[id] = (gameState.ship.cargo[id] || 0) + qty;
    }
  }

  if (c.cargoLoss) {
    for (const [id, qty] of Object.entries(c.cargoLoss)) {
      const current = gameState.ship.cargo[id] || 0;
      gameState.ship.cargo[id] = Math.max(0, current - qty);
    }
  }

  if (typeof c.spawnMissionId === "string") {
    const result = acceptMission(c.spawnMissionId);
    if (result.success) {
      pushNotification(`New mission received: ${c.spawnMissionId}`);
    }
  }
}

function pushNotification(message: string): void {
  gameState.notifications.push(message);
}
