import { gameState } from "../core/state";
import { SystemDef } from "../core/engine";

export interface Commodity {
  id: string;
  name: string;
  basePrice: number;
  volatility: number;
  tags: string[];
}

let commodities: Commodity[] = [];

export function setCommodities(data: Commodity[]): void {
  commodities = data;
}

export function getCommodities(): Commodity[] {
  return commodities;
}

export function getCommodityById(id: string): Commodity | undefined {
  return commodities.find((c) => c.id === id);
}

export interface Quote {
  commodity: Commodity;
  price: number;
}

export function getMarketQuotes(system?: SystemDef | null): Quote[] {
  const sys = system;
  if (!sys) return [];
  return commodities.map((c) => ({
    commodity: c,
    price: computeLocalPrice(sys, c)
  }));
}

export function computeLocalPrice(system: SystemDef, commodity: Commodity): number {
  const base = commodity.basePrice;
  const mod = system.marketModifiers?.[commodity.id] ?? 1;
  const volatility = commodity.volatility;
  const randomFactor = 1 + (Math.random() - 0.5) * volatility; // simple float +/- volatility/2
  const final = Math.max(1, Math.round(base * mod * randomFactor));
  return final;
}

export function buy(commodityId: string, quantity: number, price: number): { success: boolean; reason?: string } {
  const total = price * quantity;
  if (gameState.player.credits < total) {
    return { success: false, reason: "Not enough credits" };
  }
  const currentLoad = getCargoLoad();
  if (currentLoad + quantity > gameState.ship.cargoCapacity) {
    return { success: false, reason: "Not enough cargo space" };
  }

  gameState.player.credits -= total;
  gameState.ship.cargo[commodityId] = (gameState.ship.cargo[commodityId] || 0) + quantity;
  return { success: true };
}

export function sell(commodityId: string, quantity: number, price: number): { success: boolean; reason?: string } {
  const held = gameState.ship.cargo[commodityId] || 0;
  if (held < quantity) {
    return { success: false, reason: "Not enough cargo to sell" };
  }

  gameState.ship.cargo[commodityId] = held - quantity;
  gameState.player.credits += price * quantity;
  return { success: true };
}

function getCargoLoad(): number {
  return Object.values(gameState.ship.cargo).reduce((sum, qty) => sum + qty, 0);
}

export function buyFuel(quantity: number, price: number): { success: boolean; reason?: string } {
  const total = price * quantity;
  if (gameState.player.credits < total) {
    return { success: false, reason: "Not enough credits" };
  }
  const capacity = gameState.ship.maxFuel ?? gameState.ship.fuel;
  if (gameState.ship.fuel + quantity > capacity) {
    return { success: false, reason: "Fuel tanks full" };
  }

  gameState.player.credits -= total;
  gameState.ship.fuel += quantity;
  return { success: true };
}
